# v29 اپڈیٹ — پہلے یہ پڑھیں

- موجودہ application اور private DATA_DIR کا backup لیں، پھر backend بند کریں۔
- `INSTALL-V29.md` میں لکھی application files replace کریں۔ اپنی `.env`، database، DATA_DIR اور encryption keys نہ بدلیں۔
- Backend دوبارہ start کریں؛ پھر browser میں Ctrl+Shift+R کریں۔ یہ صرف CSS اپڈیٹ نہیں ہے، backend restart ضروری ہے۔
- Panel سے server delete/suspend کرنے پر Orders میں Deleted/Suspended آئے گا اور صرف Print receipt رہے گا۔ پرانی payment/receipt delete نہیں ہوگی۔
- تبدیلی فوراً push نہیں ہوتی: عام طور پر visible Orders page کی اگلی polling پر دکھے گی۔ Refresh orders تازہ panel check کرتا ہے۔ Management requests ہر بار تازہ verification کرتی ہیں۔
- Forgot password صرف panel password کا حصہ کھولتا ہے۔ Connect your server پہلے اپنی Client API key بنانے/لگانے کا طریقہ دکھاتا ہے؛ connect ہونے کے بعد live controls اور Send command دکھتے ہیں۔
- API key اپنی linked panel account کی ہونی چاہیے۔ Server online اور key کو console/command permission ہونی چاہیے۔
- پہلے disposable test server پر یہ workflow چیک کریں؛ live customer data اور private backups کسی public folder میں نہ رکھیں۔
