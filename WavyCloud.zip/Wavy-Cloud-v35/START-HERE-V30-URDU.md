# v30 — نئی registration اور الگ pages

- پہلے backup لیں۔ اپنی `.env`، private DATA_DIR، database اور encryption keys نہ بدلیں۔
- `INSTALL-V30.md` کی file list پوری deploy کریں؛ `connect-server.html` اور `forgot-password.html` دونوں نئی files لازمی upload کریں۔
- موجودہ Node backend ہی استعمال کریں۔ ضرورت کے مطابق deployment restart اور پھر Ctrl+Shift+R کریں۔
- نئے customer کے لیے My order requests → Manage service کھولنے پر receipt کے فوراً نیچے Panel registration فارم کھلا ملے گا، اور نظر اسی حصے پر جائے گی۔
- Registration مکمل ہونے کے بعد Connect your server کا link الگ HTML page کھولتا ہے۔ API، live controls اور console اب اسی الگ page پر ہیں۔
- Forgot password بھی الگ HTML page کھولتا ہے؛ پرانا panel-password والا طریقہ برقرار ہے۔
- Theme sun/moon button main site جیسے انداز میں ہے، اور theme preference سب pages پر مشترک ہے۔
- Delivered message کے ساتھ ہلکے 📦✅ اشارے شامل ہیں؛ غیر ضروری animation نہیں ہے۔
- پہلے test customer سے registration → connect → console workflow چیک کریں۔
