-- Reference schema; storage.js creates this automatically in DATA_DIR.
PRAGMA journal_mode=WAL;
PRAGMA synchronous=FULL;
PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS documents (
  name TEXT PRIMARY KEY,
  data TEXT NOT NULL CHECK(json_valid(data)),
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  kind TEXT NOT NULL,
  token TEXT NOT NULL,
  data TEXT NOT NULL CHECK(json_valid(data)),
  expires INTEGER NOT NULL,
  PRIMARY KEY(kind, token)
);
PRAGMA user_version=1;
