# Wavy Cloud v27 — automatic Minecraft mappings + requested UI updates

Start the Node backend, not a static HTML file. Node.js 24 LTS is recommended. See INSTALL-V26.md and START-HERE-V26-HINDI.md for persistent storage, legacy migration, private backups and restoring data. Keep the same DATA_DIR when upgrading from v26; the SQLite database is reused without resetting records.

## The one-time Minecraft setup

Admin → Panel API → **Automatic Minecraft defaults**.

The shared preset already contains the requested values:

- Egg ID: `1`
- Image: `ghcr.io/pterodactyl/yolks:java_25`
- Startup: `java -Xms128M -XX:MaxRAMPercentage=95.0 -Dterminal.jline=false -Dterminal.ansi=true -jar {{SERVER_JARFILE}}`
- Environment: `MINECRAFT_VERSION=latest`, `SERVER_JARFILE=server.jar`, `BUILD_NUMBER=latest`, `DL_PATH=""`
- Backups: `5`; allocations: `1`; databases: `0`; swap: `0`; I/O: `500`

**Enter your real panel location IDs once**, then click Save panel settings. IDs are not guessed. An unambiguous ID may be inherited from an existing saved mapping; verify it. If no location is configured, a mapping can be saved but server delivery remains blocked. Configure each offered country to the correct location/node pool on your panel, including its hardware family. Shared defaults cannot discover hardware automatically.

Put your Application API key and URL in the existing Panel API form yourself. No key is bundled with this build. The key is still saved encrypted in the private database.

The image and Egg ID above are your requested preset, not a guarantee of compatibility with every panel. Verify that Egg 1 allows Java 25 and defines those environment variables. Change the shared defaults once if your real Egg differs. Test connection and a paid, approved test order before using real customers.

## New plans: no repeated Egg/image/startup setup

Create the Minecraft plan in the existing Hosting editor, then publish it. A new server-delivery mapping is created automatically for Intel, EPYC and Ryzen Minecraft plans; every plan gets its own RAM, CPU and disk from its catalog specs. VPS mappings are not generated.

Use explicit resource lines, e.g.:

```text
5 GB RAM
100% CPU
40 GB NVMe storage
```

This maps to **5120 MB RAM, 100% CPU, 40960 MB disk**, with the shared Egg/image/startup/slots automatically applied. Supported RAM/disk units: GB/GiB and MB/MiB. Processor cores are supported too: `2 processor cores` = 200% CPU. Replace the old CPU spec when changing it; do not leave contradictory `2 cores` and `100% CPU` lines. Missing or conflicting quotas are rejected rather than guessed or rounded.

Catalog and generated mappings are saved in one SQLite transaction. Shared defaults and generated mappings survive restarts. Publishing a plan creates a backend mapping, **not a server or a separate product in Pterodactyl**. Server creation still requires a customer order marked **Successful + Paid** and a working panel connection.

## Existing plans, manual overrides and running servers

- Existing manually configured mappings are preserved by default.
- Auto-managed mappings update when their catalog plan resource specs change; deleting an auto-managed catalog plan removes its generated mapping.
- To migrate every existing Minecraft mapping to the preset, explicitly tick **Apply these defaults to all existing Minecraft mappings too**, then Save panel settings. This replaces per-plan manual templates for future deliveries; review hardware/location suitability first.
- Open **Advanced: per-plan overrides & legacy bulk copy**. Per plan, untick **Use shared defaults** to retain manual settings. Untick **Configure automatic delivery** to exclude the plan from automatic delivery.
- Turning off shared automation stops automatic mapping creation/updates. Existing maps remain available for delivery until disabled individually.
- Existing live servers are **not resized, recreated or changed** by catalog/template updates. Auto-managed pending orders use their purchased resource snapshot on delivery; a later price/spec edit does not alter the resources already purchased. Manual mappings still undergo the original purchased-quota safety checks.
- Legacy plans with missing explicit specs are flagged in Panel API at startup; they do not silently get guessed quotas or cause the whole website to reset. Correct their specs or use a deliberate manual override before publishing further automated changes.

## UI changes (scoped)

- Users and Orders: two compact cards per row on desktop; one column on narrow/mobile screens. Management and deletion safeguards remain.
- Other admin layout and existing hosting editors are retained. Shared advanced template fields are collapsed to keep the Panel API setup compact.
- Dark site surfaces use a cleaner graphite palette instead of the navy radial background. Light-theme colors remain, with the hero launch button changed to a clean solid-blue/white-text treatment without text shadows/filters.
- Three included WebP hero backgrounds: Minecraft, VPS datacenter, multiplayer game world. They crossfade every 6 seconds and are visible in both themes.
- Backgrounds pause when off-screen, in a hidden tab, or behind account/cart overlays. A Pause/Play control and direct scene buttons are provided. Reduced-motion users get a static scene by default and no fading animation.

## Run and verify

```sh
npm ci --omit=dev
npm start
```

Windows: `START-WEBSITE.bat`. Keep the terminal open.

```sh
npm test
```

Tests include API-level publish/edit/restart mapping persistence, atomic rejection, shared defaults, manual overrides, quota parsing, v26 durable storage/backup and existing order/panel workflows. Panel API tests use local fixtures, not your real panel.
