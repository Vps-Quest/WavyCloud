> Current v24 behavior, address lookup and live dashboard behavior is documented in README-V24.md. Older notes below may describe previous behavior.

> **v20 update:** New Minecraft orders require panel registration/linking first. Read `README-V20.md` for the current workflow, HuxRegister compatibility, and Start/Stop requirements. The instructions below also cover older orders.

# Pterodactyl setup — Wavy Cloud v19

## 1. Start and migrate
Stop the previous website server. Back up your OLD private-data folder and copy it into Wavy-Cloud-v19 to retain plans, users, orders and your changed admin password. Run START-WEBSITE.bat (or npm install, then npm start). Use http://localhost:3000, not file://. Sign in again after a restart.

## 2. Application API key (administrator)
The panel URL defaults to https://game.wavycloud.host. No real API key is bundled.

Sign in to the panel as an administrator, then Admin > Application API (usually /admin/api) > Create API Key. Grant Users and Servers Read & Write. Additional read-only Nests, Locations, Nodes and Allocations are optional if you want to retrieve setup IDs outside this website. Do not grant unnecessary Write permissions. Restrict allowed IPs to your website server's public outbound IP where possible.

Use a NEW Application key beginning ptla_. Client keys beginning ptlc_ cannot create users or servers; the admin form and backend reject them. Revoke any key that has been pasted into chat or exposed publicly. Do not paste the replacement into chat, HTML, public scripts or a ZIP.

API references:
https://pteroapi.com/docs/authentication
https://pteroapi.com/docs/api/application/users
https://pteroapi.com/docs/api/application/servers

## 3. Admin > Panel API
The new Panel API tab is beside VPS Hosting.

- Enter your panel root HTTPS URL and Application key.
- Enable automatic Minecraft delivery and save settings. The key is encrypted with AES-256-GCM in private-data/pterodactyl.json, using private-data/panel-secret.key. It is never returned by the settings API or shown in the form; leave the field blank to retain it. Other saved configuration, including egg environment values, is private but not all encrypted. Treat the entire private-data folder as sensitive.
- PTERODACTYL_API_KEY can alternatively override the stored key from the backend environment. The form shows that the environment is the key source; removing a stored key does not remove an environment override.
- Test connection performs read-only Users and Servers API calls. It creates no users/servers and confirms READ access only, not Write permissions or node capacity. After configuring mappings, use a paid approved test order to verify delivery.
- Reload settings discards unsaved edits. Settings have revision checks to avoid overwriting changes from another tab.
- Once users/servers are linked, changing the panel URL is blocked to prevent cross-panel account/ID confusion. Migrate accounts manually before moving to another panel.

## 4. Plan mapping
Select each offered Minecraft plan and enable automatic delivery for that plan.

Copy its REAL Egg ID, Docker image, startup command and ALL required egg environment variables from Pterodactyl. Enter real panel location IDs for countries you offer. A country set to 0 is unavailable for automatic delivery. Nodes at that location need free allocations and enough capacity.

The form pre-fills RAM/CPU/disk from recognizable catalog specs. Check them carefully and enter explicit values if specs do not provide them. 5 GB RAM = 5120 MB; 8 GB = 8192 MB. Four processor cores = 400% CPU. Disk values are MB too; 80 GB = 81920 MB. CPU 0 means unlimited, not zero processor capacity. Swap -1 means unlimited; otherwise use nonnegative MB. I/O weight must be 10–1000. Feature quotas control database/allocation/backup slots.

Save panel settings also saves the selected mapping. Switching plans first captures the current mapping into the unsaved form state. Save before leaving the Panel API tab. Saved orders preserve their purchased specs; changing a mapping to conflict with a purchased order's recognizable RAM, CPU or disk specs causes delivery to fail instead of supplying wrong quotas.

Pterodactyl provisions Minecraft/game servers here, NOT VPS machines. VPS and mixed Minecraft/VPS orders require manual fulfilment. Map all offered Minecraft plans before going live. pterodactyl.example.json is disabled and only an advanced template, not a working configuration.

## 5. Exact approval rule
Admin > Orders > set Status = Successful AND Payment status = Paid > Save status.

- Successful without Paid: Awaiting payment; no user or server created.
- Paid while Pending: no user or server created.
- Both Successful and Paid: validate all plan mappings, find/create the customer panel user, then create one server for each purchased unit with the mapped resource quotas.
- Paid is a MANUAL confirmation of a payment you independently verified. No payment gateway or payment collection is implemented. Marking Paid does not take money from a customer.
- Stable external IDs prevent duplicate users/servers when retrying. Concurrent deliveries for the same customer share a panel-user creation operation. Created units are persisted after each API response.
- If setup/API/capacity fails, the order shows an honest error. Fix it and save Successful + Paid again to retry. There is no automatic background retry queue.
- API creation success may still mean Wings is installing; it does not claim the server is running.

## 6. Customer panel setup — directly in My Orders
For a new website-managed panel account, the delivered order shows Complete panel registration. The account already exists; this form finishes username/password setup rather than creating a duplicate account.

- Email is the website email and read-only. Website signup currently has no email verification, so arbitrary existing panel email accounts are not automatically claimed.
- The customer chooses a valid 3–32 character panel username and a separate 12–128 character panel password, confirms it, and supplies their CURRENT website password to authorize the change.
- Username/password update is performed by the backend Application API only after verifying matching email, non-admin status and the stable website external ID. The website password is not changed or copied; only its hash is stored.
- The chosen new panel password is not saved locally or returned by the API. Password inputs are cleared after a submission. Existing encrypted initial-password material is deleted after the new password is set.
- Before setup, Manage now may show an initial generated password for a newly created user. Existing external panel accounts must change passwords in the panel itself; website-managed account setup cannot overwrite those credentials or administrator credentials.
- Independent ownership verification is required before an administrator links an existing panel account in the advanced email-to-user-ID JSON. This is not a substitute for email verification.

## 7. Server rename and live status
My Orders > Server name & live status:

- Choose one of the order's servers and rename it. The backend verifies the customer owns both the saved order and the current panel server. It updates only name, keeping owner/external ID and resource limits unchanged.
- Application API gives installation/suspension/configuration information. It does NOT provide trusted live Running/Offline state by itself.
- To show live runtime, the customer signs in to THEIR panel account, opens Account > API Credentials (usually /account/api), creates THEIR OWN ptlc_ Client key, then enters it in Connect your own Client key on My Orders.
- The key must return the exact non-admin panel user ID and email for that customer. Another user's key or an administrator key is rejected. It is encrypted at rest and never sent to other customers or returned by APIs.
- Runtime and usage are read from /api/client/servers/{identifier}/resources. Without a connected key, runtime is unknown; it is not fabricated as Running or Offline. Revoked keys/network failures show unavailable status.
- Expanded server controls refresh about every 30 seconds while the page is visible. Closed controls do not continually poll. Refresh server status allows a manual check. Disconnect saved key removes the website's stored key, but does not revoke it in Pterodactyl.

References:
https://pteroapi.com/docs/api/client/account
https://pteroapi.com/docs/api/client/servers

## 8. Limits and security
Validity is 30 days from completed API creation of all order units. Automatic expiry suspension, renewal billing and payment gateways are not included. Suspended is an ORDER-tracking status only: suspend the server manually in the actual panel. Changing a delivered order to Unpaid or Pending does not delete/suspend an existing server.

Use HTTPS for both website and panel. Set NODE_ENV=production and PUBLIC_ORIGIN=https://your-website.example. Change the temporary admin password first. Back up private-data together with panel-secret.key; do not move it under a public web document root or publish it. JSON persistence and memory sessions require one Node process; this is not a full production billing platform.

PTERO_TEST_MODE exists only to allow localhost HTTP mock tests; never set it on the production server. The supplied public panel could not be inspected through page extraction in this session. Live delivery is NOT verified: no usable Application key was supplied. All credentials in automated tests are fabricated placeholders, never the user-supplied key.
