# Wavy Cloud v23 — complete merged website

## Safe upgrade on Windows
1. Stop the old server with Ctrl+C and back up the entire current website folder.
2. Extract this ZIP into a NEW folder.
3. While both servers are stopped, COPY your existing `private-data` folder into `Wavy-Cloud-v23`, beside `server.js`. Keep the backup. Include `panel-secret.key`: it is required to decrypt your saved panel keys.
4. Preserve your custom environment variables and environment startup script. If you use a custom DATA_DIR, preserve that setting. Copy any custom `.env` file used by your startup script too; this server does not automatically load `.env` files.
5. Run `START-WEBSITE.bat` inside the new folder with Node.js 20+. It installs the nodemailer and ws packages if missing; first installation needs an internet connection. Keep the window open, and do not run the old server simultaneously.
6. Open http://localhost:3000 and press Ctrl+F5. Admin: http://localhost:3000/admin.html. Services: http://localhost:3000/orders.html. Do not open HTML files directly from disk.

The archive contains no private-data, real credentials or live API keys. Your records and saved keys come from your copied local private-data. For a fresh installation only, the temporary admin is admin@gmail.com / admin. Change it before public deployment. Migrated installations retain the existing admin login.

## Services and panel setup
- My Order Requests now shows compact, numbered service cards with the hosting type, server name, plan specifications and monthly total.
- Active cards have Manage now and Print receipt. Pending/unpaid/blocked cards have View request and Print receipt, with no server management controls.
- Order details are collapsed by default. Printing produces a small Wavy Cloud logo-branded order receipt, not the full management screen.
- Manage opens a separate service view. First-time panel setup asks for username, email, current website password and paired new/confirm panel-password fields on desktop. On phones the fields stack for readability.
- The panel account is provisioned on approval/delivery, because Pterodactyl requires a server owner before creation. Finishing setup sets the username/password for that owned account; it does not create a duplicate account.
- Once setup succeeds, the first-time heading is removed, the setup form collapses and the persistent control becomes Reset your panel password / username. Later services use the same already-configured account.
- The existing product-delivered notification is retained for active successfully delivered services.

## Status and payment — IMPORTANT behavior change
- Successful + Paid creates the mapped Minecraft server, or restores an existing delivered server after a successful panel synchronization.
- Suspended, Pending, Unpaid OR Not processed disables service-management endpoints on the website and requests suspension of every existing server linked to that order in Pterodactyl.
- Changing a paid delivered order to Unpaid/Not processed therefore suspends its servers; these are not decorative receipt statuses. Payment date is cleared when payment is no longer Paid.
- Reapproval checks existing server identities; it does not intentionally create duplicate servers.
- Access-sync failures are shown explicitly. Website access is blocked even if the panel is unreachable, but the server may still be running in the panel. Fix the error and click Save status again to retry. Verify the server in the panel if a sync fails.
- Access gates apply to rename, power, status, console, credentials and setup. Open console sessions are closed on revoked access; the browser management screen detects changes while open.
- No automatic expiry/suspension scheduler or renewal billing is included. Existing 30-day dates remain; expired services cannot use website management. Saving status checks expiry before restoring panel access.

## Own Client API key, live metrics and logs
- The administrator Application key (ptla_) cannot retrieve or mint a customer's Client API key (ptlc_). It is never shared with customers or used as a shared power-control key.
- Manage → Server name & live status → Connect your own Client key → Get your API key opens the customer's panel API-credentials page. The customer creates their own key there and pastes it into Connect key securely once.
- Key ownership and non-admin status are checked. The key is encrypted in private-data and is never returned to the form. It can be disconnected.
- With a valid own Client key, the service shows Start/Stop/Restart and real address, uptime, CPU load, memory, disk and inbound/outbound network totals when the panel provides them. Missing metrics say Unavailable; they are not invented. Network values are cumulative data totals, not speed measurements.
- Connect console shows read-only live/recent logs from Wings. It does not provide arbitrary terminal commands or stored historical logs. Use the hosting panel for commands. Sessions end after ten minutes or when the panel JWT expires; reconnect when needed.
- Console transport is proxied by the backend using short-lived, single-use, session-bound tickets. Neither Application keys, saved Client keys nor Wings JWTs are sent to the website browser.
- Real power/console needs a healthy Wings node and working TLS/WebSocket endpoints. For public deployment, your website's reverse proxy must forward WebSocket Upgrade/Connection headers to Node for `/api/account/console`, and PUBLIC_ORIGIN must match the public website origin. The Node backend needs network access to both the panel and the Wings socket supplied by the panel. PTERO_TEST_MODE is only for automated local tests; do not enable it in production.

## Admin cleanup and deleting customers
- Equal-format navigation buttons, compact customer rows/order cards, expandable payment controls and a persisted light/dark theme toggle.
- Delete user requires typing the customer's email. It suspends linked servers, removes the WEBSITE account, revokes sessions and removes related website notifications. Order history remains for audit, and becomes read-only if the customer is gone.
- This action does NOT delete Pterodactyl users or server files. If panel suspension fails, account deletion is aborted and an explicit error is shown; affected website orders remain blocked so management cannot continue while suspension is being fixed.

## Existing setup and limits
The Intel Minecraft bulk setup and per-plan limits are preserved. No extra patch is needed. VPS automatic delivery, a payment gateway and QR payment setup are not added in this release. No changes to HuxRegister are required.
The Application key still needs Users and Servers Read & Write. Per-plan Egg/image/startup/environment/location IDs and node capacity/allocations must be correct. “No eligible node” is a panel deployment configuration/capacity issue, not fixed by the UI redesign.

## Validation
63 backend test cases passed, including status/payment synchronization, suspension-failure handling, ownership gates, console-ticket isolation/replay prevention, real resource fields and safe deletion. Local browser checks covered paired setup fields, setup completion/reload, service cards, logo receipts, live metrics/logs, management revocation and admin themes with no browser exceptions. Desktop 1440px and mobile 390px render states were inspected.
All panel/console tests use isolated mock services, not your production panel. Live server creation, suspension, metrics and Wings console have not been verified against game.wavycloud.host here. After migration, test one owned server with your actual key and working node before using this for customers.
