# v35 — Current release

Read `START-HERE-V35-ROMAN-URDU.md` and `INSTALL-V35.md` first. Adds Send Service with explicit recipient acceptance and verified Pterodactyl ownership transfer, plus Account Info/profile/security/self-deletion. Preserve your private DATA_DIR/database and `.env`; restart the backend. Existing v34 features are included. Older release notes below are historical and superseded by the v35 guide.

# v33 — Historical release

Read `START-HERE-V33-ROMAN-URDU.md` and `INSTALL-V33.md` first. Panel API now has a saved concurrent demo capacity (default 10); customers see slot availability/wait estimates and complete Pterodactyl login in the demo dialog. Specs stay 2 GB / 100% CPU / 5 GB for 30 minutes. Expiry deletes the demo server, never the panel account. Older release notes below are historical; v33 capacity behavior supersedes the old fixed three-slot limit.

# v32.1 hotfix

Demo location loading and session-token refresh are fixed. Read `HOTFIX-V32.1-ROMAN-URDU.md` first. Restart the backend after updating. Existing v32 features and payment settings are preserved.

# v32 update

Read **START-HERE-V32-ROMAN-URDU.md** and **INSTALL-V32.md** first. Two additions: inactive-service removal and optional 30-minute Minecraft trials. Preserve your existing environment/private database, restart the backend, then enable demos in Admin → Panel API when ready. Payment settings are unchanged.

# v31 update

Read **START-HERE-V31-URDU.md** and **INSTALL-V31.md** first. Restart the backend after upgrading. Configure payment details, your real Discord invite and coupons in Admin → Payments & coupons. Preserve your existing `.env` and private DATA_DIR/database.

# v27 update

Read **START-HERE-V27-HINDI.md** and **INSTALL-V27.md** first. New Minecraft plans map automatically from their specs; configure real panel location IDs once. Preserve your existing DATA_DIR.

# v26 update

Read **INSTALL-V26.md** first. Requires Node.js 22.13+ (24 LTS recommended). Keep DATA_DIR on persistent storage; preserve your existing private-data folder when upgrading. SQLite auto-migrates v24 data.

# Pixa AI Landing Page

A modern, responsive landing page for Pixa AI — your all-in-one AI companion. Presenting all your AI models in one place through a sleek, minimal UI.

## 📖 Overview

![Screenshot](./README-IMGS/light-preview.png)
![Screenshot](./README-IMGS/dark-preview.png)

This landing page is designed to showcase Pixa AI’s key offerings with a clean and modern user interface. Built using React.js and Tailwind CSS, it provides a fully responsive, visually engaging experience.

## ⚙️ Tech Stack

- HTML
- CSS
- Tailwind CSS
- Javascript

## 🔋 Features

- Hero Section with an engaging introduction, clear headline, subtext, and call-to-action button.
- Service Highlights showcasing core AI features like image generation, video creation, coding assistance, document generation, and web app debugging, all presented in a clean layout.
- Parallax and scroll-triggered animations for smooth interactive effects that enhance user engagement.
- Dark and Light Mode support for seamless theme switching and optimal viewing experience.
Modern visuals and stylish gradients applied to cards, buttons, and backgrounds using Tailwind CSS.
- Fully responsive design ensuring consistent functionality and visual appeal across desktop, tablet, and mobile devices.
- Advanced UI elements including bento grids, interactive dropdowns, layered backgrounds, and hover effects.
- Clean, reusable, and maintainable code architecture optimized for customization and scalability.

## 📄 License
> This project is licensed under the MIT License.
