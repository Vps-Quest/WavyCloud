(()=>{'use strict';
 const images=[...document.querySelectorAll('.hero-scene')],hero=document.querySelector('.hero-content');if(images.length<2||!hero)return;
 const motion=matchMedia('(prefers-reduced-motion: reduce)');let active=0,visible=true,timer=null,generation=0;
 const running=()=>!motion.matches&&visible&&!document.hidden&&!document.body.classList.contains('modal-open');
 function schedule(){clearTimeout(timer);timer=null;generation++;if(!running())return;const token=generation;timer=setTimeout(async()=>{const index=(active+1)%images.length;try{if(!images[index].complete||!images[index].naturalWidth)await images[index].decode();if(token!==generation||!running())return;active=index;images.forEach((image,i)=>image.classList.toggle('is-active',i===index));}catch(_){}schedule();},6000);}
 document.addEventListener('visibilitychange',schedule);new MutationObserver(schedule).observe(document.body,{attributes:true,attributeFilter:['class']});if('IntersectionObserver' in window)new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;schedule();},{threshold:.1}).observe(hero);motion.addEventListener('change',schedule);schedule();
})();
