(()=>{
 'use strict';
 let button=document.querySelector('[data-discord-join]');const status=document.getElementById('discord-join-status');
 if(!button)return;
 button.onclick=()=>{status.hidden=false;status.textContent='Our Discord invite is not available yet. Please contact support.';};
 function connect(url){if(!/^https:\/\/(discord\.gg\/[A-Za-z0-9-]+|discord\.com\/invite\/[A-Za-z0-9-]+)\/?$/.test(url||''))return;
  const link=document.createElement('a');link.className=button.className;link.innerHTML=button.innerHTML;link.href=url;link.target='_blank';link.rel='noopener noreferrer';link.setAttribute('aria-label','Join Discord (opens in a new tab)');button.replaceWith(link);button=link;status.hidden=true;
 }
 connect(window.WavyCloudConfig?.discordInviteUrl);
 fetch('/api/payments',{cache:'no-store',credentials:'same-origin'}).then(r=>{if(!r.ok)throw Error('Unavailable');return r.json();}).then(data=>connect(data.discordUrl)).catch(()=>{});
})();
