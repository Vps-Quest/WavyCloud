(() => {
 'use strict';
 const KEY='wavy-server-cart-v1';let memory=[];
 function canonicalId(id){return ['drift','current','storm'].includes(id)?'minecraft-intel-'+id:id;}
 function find(catalog,id){const [service,family]=String(id).split('-');return catalog?.families?.[service]?.[family]?.available?catalog.plans[service+'-'+family]?.find(p=>p.id===id):null;}
 function normalize(input,catalog){const map=new Map();let used=0;if(!Array.isArray(input))return [];
  for(const row of input){const id=canonicalId(typeof row==='string'?row:row?.planId),q=typeof row==='string'?1:row?.quantity;if(typeof id!=='string'||!Number.isInteger(q)||q<1||!find(catalog,id))continue;const quantity=Math.min(q,50-used);if(quantity<=0)break;map.set(id,(map.get(id)||0)+quantity);used+=quantity;}
  return [...map].map(([planId,quantity])=>({planId,quantity}));
 }
 function read(catalog){let rows=memory;try{rows=JSON.parse(localStorage.getItem(KEY)||'[]');}catch(_){}return normalize(rows,catalog);}
 function write(rows){memory=rows;try{localStorage.setItem(KEY,JSON.stringify(rows));localStorage.removeItem('wavy-order-request-id');}catch(_){}window.dispatchEvent(new Event('wavy-cart-update'));}
 function count(rows){return rows.reduce((n,p)=>n+p.quantity,0);}
 function update(catalog,id,delta){const rows=read(catalog),item=rows.find(p=>p.planId===id);if(delta>0&&count(rows)>=50)return false;if(item)item.quantity=Math.max(1,item.quantity+delta);else if(delta>0&&find(catalog,id))rows.push({planId:id,quantity:1});else return false;write(rows);return true;}
 function remove(catalog,id){write(read(catalog).filter(p=>p.planId!==id));}
 window.WavyCart={KEY,read,write,find,count,update,remove,canonicalId};
})();
