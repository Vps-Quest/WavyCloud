(() => {
 const form=document.getElementById('login-form');if(!form)return;
 const msg=document.createElement('p');msg.className='auth-feedback';msg.setAttribute('role','status');form.append(msg);
 form.addEventListener('submit',async e=>{
  e.preventDefault();const btn=form.querySelector('[type=submit]');btn.disabled=true;msg.textContent='Signing in…';
  try{
   const r=await fetch('/api/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:form.querySelector('[type=email]').value.trim(),password:form.querySelector('[autocomplete="current-password"]').value,remember:form.querySelector('[type=checkbox]').checked})});
   const b=await r.json();if(!r.ok)throw Error(b.error||'Sign-in failed.');location.href='admin.html';
  }catch(err){msg.textContent=err instanceof SyntaxError?'Admin requires the Node.js server. Run npm start.':err.message;}finally{btn.disabled=false;}
 });
})();
