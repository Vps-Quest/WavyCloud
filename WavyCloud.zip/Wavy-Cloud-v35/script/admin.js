(async () => {
  'use strict';
  const $ = id => document.getElementById(id);
  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  };
  if(localStorage.getItem('wavy-theme')==='light')document.documentElement.classList.add('tw-light');document.getElementById('admin-theme').onclick=()=>{document.documentElement.classList.toggle('tw-light');localStorage.setItem('wavy-theme',document.documentElement.classList.contains('tw-light')?'light':'dark');};
  let csrf = '', catalog, service = 'minecraft', family = 'intel', view = 'home', dirty = false, saving = false, orderCache = []; 
  const files = {intel:'Intel-Xenon-plans.html', epyc:'Amd-Epyc-plans.html', ryzen:'Amd-Ryzen-plans.html'};
  async function api(url, method = 'GET', body) {
    if(location.protocol==='file:')throw Error('Offline preview. Run START-WEBSITE.bat, then open http://localhost:3000/admin.html.');
    const r = await fetch(url, {
      method, headers: {'Content-Type':'application/json', 'X-CSRF-Token':csrf},
      ...(body !== undefined ? {body:JSON.stringify(body)} : {})
    });
    let b;
    try { b = await r.json(); }
    catch (_) { throw Error('Run the Node.js backend with npm start. Static hosting cannot save admin changes.'); }
    if (!r.ok) throw Error(b.error || 'Request failed.');
    return b;
  }
  function changed() {
    dirty = true;
    $('save-state').textContent = 'Unpublished changes';
    $('save-state').style.color = '#f5cf8b';
  }
  function field(parent, title, value, onchange, options = {}) {
    const {tag='input', type='text', wide=false, max=2000} = options;
    const label = el('label', wide ? 'wide' : '', title), input = el(tag);
    input.value = value;
    if (tag === 'input') input.type = type;
    input.maxLength = max;
    if (type === 'number') { input.min = 0; input.max = 1000000; input.step = '.01'; }
    input.addEventListener('input', () => {
      onchange(type === 'number' ? Number(input.value) : input.value);
      changed();
    });
    label.append(input); parent.append(label);
    return input;
  }
  function imageEditor(value, set, kind) {
    const wrapper = el('div', 'image-editor'), preview = el('img', 'image-preview');
    preview.alt = kind;
    preview.src = value || './assets/logo/wavy-cloud-mark.png';
    const inputs = el('div', 'image-inputs');
    const url = field(inputs, 'Image URL or local assets path', value.startsWith('data:') ? '' : value, v => {
      set(v); preview.src = v || './assets/logo/wavy-cloud-mark.png';
    });
    url.placeholder = value.startsWith('data:') ? 'Uploaded image saved — paste URL to replace' : 'https://… or ./assets/images/…';
    const label = el('label', '', 'Or upload a new image'), upload = el('input');
    upload.type = 'file'; upload.accept = 'image/png,image/jpeg,image/webp,image/gif';
    upload.addEventListener('change', () => {
      const file = upload.files[0];
      if (!file) return;
      if (file.size > 2*1024*1024 || !['image/png','image/jpeg','image/webp','image/gif'].includes(file.type)) {
        alert('Choose a PNG, JPG, WebP or GIF no larger than 2 MB.'); upload.value = ''; return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        set(reader.result); preview.src = reader.result;
        url.value = ''; url.placeholder = 'Uploaded image — paste URL to replace'; changed();
      };
      reader.readAsDataURL(file);
    });
    label.append(upload);
    inputs.append(label, el('span', 'image-hint', 'PNG, JPG, WebP or GIF · max 2 MB. Publish to apply.'));
    wrapper.append(preview, inputs);
    return wrapper;
  }
  function renderHome(){
    const root=$('brand-editor');root.replaceChildren();
    const name=field(root,'Website name',catalog.home.brandName,v=>catalog.home.brandName=v,{max:60});name.parentElement.className='brand-name-field';
    root.append(imageEditor(catalog.home.logo,v=>catalog.home.logo=v,'Website logo'));
    const nav=$('nav-editor');nav.replaceChildren();
    for(const [key,label]of Object.entries({solutions:'Solutions label',features:'Why Wavy Cloud label',locations:'Locations label',faq:'FAQ label'}))field(nav,label,catalog.home.navLabels[key],v=>catalog.home.navLabels[key]=v,{max:40});
  }
  async function loadPayments(){const host=$('payments-panel');host.replaceChildren(el('h2','','Payments & coupons'));try{const settings=await api('/api/admin/payments');if(view!=='payments')return;const form=el('form','payments-admin'),grid=el('div','payments-method-grid');for(const [key,m]of Object.entries(settings.methods)){const card=el('section','admin-family');card.append(el('h3','',({card:'Card payment',easypaisa:'Easypaisa',jazzcash:'JazzCash',upi:'UPI'})[key]));const label=el('label','','Availability'),select=el('select');for(const [v,t]of [['true','Available'],['false','Coming soon']]){const o=el('option','',t);o.value=v;select.append(o);}select.value=String(m.available);select.onchange=()=>m.available=select.value==='true';label.append(select);card.append(label);for(const [f,title]of Object.entries({bank:'Bank',name:'Account holder name',number:'Account / phone number',method:'Method label',instructions:'Payment instructions'})){const l=el('label','',title),input=el(f==='instructions'?'textarea':'input');input.value=m[f];input.maxLength=f==='instructions'?1500:150;input.oninput=()=>m[f]=input.value;l.append(input);card.append(l);}grid.append(card);}form.append(grid);const discord=el('label','','Discord invite URL (UPI)'),url=el('input');url.type='url';url.placeholder='https://discord.gg/your-invite';url.value=settings.discordUrl;url.oninput=()=>settings.discordUrl=url.value;discord.append(url);form.append(discord,el('h3','','Coupons · all products'),el('p','order-meta','Discount applies to the monthly total after existing plan offers. Codes can include letters, numbers, hyphens and underscores.'));const list=el('div','coupon-admin-list');function coupons(){list.replaceChildren();for(const c of settings.coupons){const row=el('div','coupon-admin-row');for(const [key,label,type]of [['code','Coupon code','text'],['percent','Discount %','number']]){const l=el('label','',label),i=el('input');i.type=type;i.value=c[key];if(type==='number'){i.min='.01';i.max='100';i.step='.01';}else i.maxLength=32;i.required=true;i.oninput=()=>c[key]=type==='number'?Number(i.value):i.value;l.append(i);row.append(l);}const enabled=el('label','','Enabled'),check=el('input');check.type='checkbox';check.checked=c.enabled;check.onchange=()=>c.enabled=check.checked;enabled.append(check);const remove=el('button','button button-ghost','Remove');remove.type='button';remove.onclick=()=>{settings.coupons.splice(settings.coupons.indexOf(c),1);coupons();};row.append(enabled,remove);list.append(row);}}coupons();const add=el('button','button button-ghost','+ Add coupon');add.type='button';add.onclick=()=>{settings.coupons.push({code:'',percent:20,enabled:true});coupons();};const save=el('button','button button-primary','Save payments & coupons'),feedback=el('p');save.type='submit';feedback.setAttribute('role','status');form.onsubmit=async e=>{e.preventDefault();save.disabled=true;try{await api('/api/admin/payments','PUT',settings);feedback.textContent='Payment methods and coupons saved.';}catch(e){feedback.textContent=e.message;}finally{save.disabled=false;}};form.append(list,add,save,feedback);host.append(form);}catch(e){host.append(el('p','',e.message));}}
  function render() {
    document.querySelectorAll('[data-view]').forEach(btn=>{const active=btn.dataset.view===view&&(view!=='hosting'||btn.dataset.service===service);btn.classList.toggle('active',active);btn.setAttribute('aria-pressed',String(active));});
    for(const name of ['home','hosting','users','orders','panel','payments'])$(name+'-panel').hidden=name!==view;
    document.querySelector('.admin-save').hidden=!['home','hosting'].includes(view);
    if(view==='payments'){loadPayments();return;}
    if(view==='home'){renderHome();return;}
    if(view==='users'){loadUsers();return;}
    if(view==='orders'){loadOrders();return;}
    if(view==='panel'){loadPanel();return;}
    $('background-editor').replaceChildren(imageEditor(catalog.backgrounds[service],v=>catalog.backgrounds[service]=v,'Home page hosting background'));
    const grid=$('families');grid.replaceChildren();
    for(const fam of ['intel','epyc','ryzen']){
      const f=catalog.families[service][fam],box=el('article','admin-family');box.append(el('h3','',f.name));
      const label=el('label','','Availability'),select=el('select');
      for(const [value,text]of [['true','Available now'],['false','Coming soon']]){const option=el('option','',text);option.value=value;select.append(option);}
      select.value=String(f.available);select.addEventListener('change',()=>{f.available=select.value==='true';changed();});label.append(select);box.append(label,imageEditor(f.logo,v=>f.logo=v,f.name+' logo'));grid.append(box);
    }
    renderPlans();
  }
  function renderPlans(){
    family=$('plan-family').value;const plans=catalog.plans[service+'-'+family];$('plan-count').textContent=plans.length+' plans';$('preview-plans').href=files[family]+'?service='+service;const grid=$('plan-editors');grid.replaceChildren();
    if(!plans.length)grid.append(el('p','empty-plans','No plans yet. Add your first plan above.'));
    plans.forEach((p,index)=>{
      const box=el('article','plan-editor'),heading=el('div','plan-editor-heading'),title=el('h3','',`${index+1} / ${p.name}`),del=el('button','button delete-plan','Delete');del.type='button';del.setAttribute('aria-label','Delete '+p.name);
      del.addEventListener('click',()=>{if(confirm(`Delete ${p.name}? Applied when you publish.`)){plans.splice(index,1);changed();renderPlans();}});heading.append(title,del);box.append(heading);
      const quick=el('div','plan-fields');field(quick,'Plan name',p.name,v=>{p.name=v;title.textContent=`${index+1} / ${v}`;},{max:100});const preview=el('p','admin-price-preview');const refreshPrice=()=>{const amount=window.WavyPricing.price(p);preview.textContent='Customer price: '+window.WavyPricing.money(amount.unitCents)+' / month'+(amount.discountPercent?' · '+amount.discountPercent+'% off':'');};field(quick,'Base monthly price · USD',p.price,v=>{p.price=v;refreshPrice();},{type:'number'});box.append(quick,preview);
      const more=el('details','plan-extra');more.append(el('summary','','More details · offer, description & specs'));
      const fields=el('div','plan-fields');field(fields,'Plan tag',p.type,v=>p.type=v,{max:100});field(fields,'Order button label',p.button,v=>p.button=v,{max:100});
      const offer=field(fields,'Red offer · percentage auto-discounts price',p.offer||'',v=>{p.offer=v;refreshPrice();},{wide:true,max:30});offer.setAttribute('aria-label','Red offer · percentage auto-discounts price');offer.placeholder='20% OFF';offer.parentElement.append(el('span','image-hint','Use 20% OFF to automatically discount the base monthly price.'));refreshPrice();
      field(fields,'Description',p.description,v=>p.description=v,{tag:'textarea',wide:true});field(fields,'Specifications · one per line',p.specs.join('\n'),v=>p.specs=v.split('\n').map(s=>s.trim()).filter(Boolean),{tag:'textarea',wide:true,max:9000});
      const label=el('label','admin-checkbox wide'),check=el('input');check.type='checkbox';check.checked=p.popular;check.addEventListener('change',()=>{p.popular=check.checked;changed();});label.append(check,document.createTextNode('Highlight as most popular'));fields.append(label);more.append(fields);box.append(more);grid.append(box);
    });
  }
  function formatDate(value){return new Date(value).toLocaleString();}
  async function loadUsers(){
    $('user-list').textContent='Loading users…';
    try{
      const data=await api('/api/admin/users');$('mail-state').className=data.mailConfigured?'':'mail-warning';$('mail-state').textContent=data.mailConfigured?'Registration and order email notifications are enabled. Delivery status is shown below.':'Email delivery is not configured. Users and notifications are saved here. Set SMTP and ADMIN_NOTIFY_EMAIL on the server to receive emails.';
      const grid=el('div','admin-user-grid');for(const u of [...data.users].reverse()){
        const card=el('article','customer-card'),info=el('div','customer-info');info.append(el('h3','',u.name),el('p','user-email',u.email),el('p','order-meta',u.orderCount+' orders · Joined '+new Date(u.createdAt).toLocaleDateString()));const remove=el('button','button button-ghost danger-button','Delete user');remove.type='button';remove.onclick=async()=>{const typed=window.prompt('Delete this WEBSITE account? Linked servers will be suspended and sessions revoked. Order history is retained. Panel users/servers are NOT deleted. Type the customer email to confirm:', '');if(typed===null)return;if(typed!==u.email){$('feedback').textContent='Email did not match. No user deleted.';return;}remove.disabled=true;try{const r=await api('/api/admin/users/delete','POST',{id:u.id,confirmEmail:typed});$('feedback').textContent=r.message;await loadUsers();}catch(e){$('feedback').textContent=e.message;}finally{remove.disabled=false;}};card.append(info,remove);grid.append(card);
      }
      $('user-list').replaceChildren(data.users.length?grid:el('p','empty-plans','No registered customers yet.'));
      const list=$('notification-list');list.replaceChildren();for(const n of data.notifications.slice(0,10)){
        const card=el('article','notification-card');card.append(el('h4','',n.subject),el('p','notification-meta',`${formatDate(n.createdAt)} · Email: ${n.mailStatus}`));list.append(card);
      }
      if(!data.notifications.length)list.append(el('p','','No notifications yet.'));
    }catch(e){$('user-list').textContent=e.message;}
  }
  async function loadOrders(){
    $('order-list').textContent='Loading orders…';try{const result=await api('/api/admin/orders');orderCache=result.orders;renderOrders();const info=el('p','order-meta',result.integration.message);$('order-list').prepend(info);}catch(e){$('order-list').textContent=e.message;}
  }
  function renderOrders(){
    const filter=$('order-filter').value,list=$('order-list');list.replaceChildren();
    const visible=orderCache.filter(o=>filter==='all'||o.status===filter);
    for(const o of visible){
      const card=el('article','order-card'),top=el('div','order-card-top'),info=el('div');info.append(el('h3','',o.serverName||'Order '+o.id.slice(0,8)),el('p','order-meta',o.userName+' · '+o.userEmail+' · '+formatDate(o.createdAt)));top.append(info,el('span','order-status '+o.status,o.status));card.append(top,el('p','compact-order-summary',o.items.map(p=>p.name+' × '+(p.quantity||1)).join(' / ')+' · $'+o.total.toFixed(2)+' / mo · '+o.paymentStatus+' · '+(o.location||'France')));if(o.delivery)card.append(el('p','order-delivery-summary','Delivery: '+o.delivery.state+' · '+o.delivery.message));if(o.access)card.append(el('p',o.access.state==='Failed'?'order-error':'order-access-summary',o.access.message));
      const edit=el('details','admin-order-details');edit.append(el('summary','','Manage order / payment'));card.append(edit);
      if(o.coupon)edit.append(el('p','order-meta','Coupon: '+o.coupon.code+' · '+o.coupon.percent+'% · saved $'+o.couponSavings.toFixed(2)));if(o.paymentProof){edit.append(el('p','order-meta','Sender: '+o.paymentProof.senderName+' · Transaction: '+o.paymentProof.transactionId));const proof=el('a','button button-ghost','View payment screenshot ↗');proof.href='/api/payment-proof/'+encodeURIComponent(o.id);proof.target='_blank';proof.rel='noopener';edit.append(proof,el('p','order-meta','Proof submitted — verify independently before marking Paid.'));}
      if(o.kind==='Demo'){edit.append(el('p','order-meta','Free 30-minute demo · '+o.demo.state+' · expires '+formatDate(o.delivery.expiresAt)),el('p','order-meta',o.demo.cleanupError||'Automatic suspension and deletion; no payment needed.'));list.append(card);continue;}
      const controls=el('div','order-controls'),label=el('label','','Status'),select=el('select');for(const status of ['Pending','Successful','Suspended']){const option=el('option','',status);option.value=status;select.append(option);}select.value=o.status;select.setAttribute('aria-label','Order status');label.append(select);const noteLabel=el('label','','Admin note'),note=el('input');note.type='text';note.maxLength=1000;note.value=o.note;note.placeholder='Payment checked, unpaid, suspension reason…';noteLabel.append(note);const save=el('button','button button-ghost','Save status');save.type='button';const feedback=el('p','order-feedback');feedback.setAttribute('role','status');
      const payLabel=el('label','','Payment status'),pay=el('select');for(const v of ['Not processed','Unpaid','Paid']){const op=el('option','',v);op.value=v;pay.append(op);}pay.value=o.paymentStatus||'Not processed';payLabel.append(pay);const dateLabel=el('label','','Payment date / time (your local time)'),paidAt=el('input');paidAt.type='datetime-local';if(o.paidAt){const date=new Date(o.paidAt);paidAt.value=new Date(date-date.getTimezoneOffset()*60000).toISOString().slice(0,16);}dateLabel.append(paidAt);
      save.addEventListener('click',async()=>{save.disabled=true;try{const data=await api('/api/admin/orders','PUT',{id:o.id,status:select.value,note:note.value,updatedAt:o.updatedAt,paymentStatus:pay.value,paidAt:pay.value==='Paid'&&paidAt.value?new Date(paidAt.value).toISOString():null});Object.assign(o,data.order);renderOrders();$('feedback').textContent=data.order.access?.state==='Failed'?data.order.access.message:'Order saved. '+(data.order.access?.message||data.order.delivery?.message||'Waiting for approval/payment.');}catch(e){feedback.textContent=e.message;}finally{save.disabled=false;}});controls.append(label,payLabel,dateLabel,noteLabel,save);edit.append(controls,feedback);
      if(o.history?.length){const history=el('details','plan-extra');history.append(el('summary','','Status history'));for(const h of o.history)history.append(el('p','order-meta',`${formatDate(h.at)} · ${h.from} → ${h.to}${h.paymentTo?' · Payment: '+h.paymentTo:''}${h.note?' · '+h.note:''}`));edit.append(history);}
      list.append(card);
    }
    if(!visible.length)list.append(el('p','empty-plans','No order requests in this view.'));
  }
  let panelSettings=null,mappingPlan='',bulkDraft=null,bulkSignature='';
  function panelInput(label,value,id,type='text'){const wrap=el('label','',label),input=el('input');input.id=id;input.type=type;input.value=value??'';if(type==='number'){input.min=(id==='map-swap'||id==='auto-swap')?'-1':'0';input.step='1';}wrap.append(input);return wrap;}
  function planById(id){return Object.values(catalog.plans).flat().find(p=>p.id===id);}
  function defaultLimits(plan){const specs=(plan.specs||[]).join(' '),ram=specs.match(/(\d+(?:\.\d+)?)\s*GB\s*RAM/i),disk=specs.match(/(\d+(?:\.\d+)?)\s*GB\s*(?:NVMe|SSD|disk|storage)/i),cores=specs.match(/(\d+(?:\.\d+)?)\s*(?:processor|CPU)\s*cores/i),cpu=specs.match(/(\d+(?:\.\d+)?)\s*%\s*CPU|CPU\s*:?\s*(\d+(?:\.\d+)?)\s*%/i);return {memory:ram?Number(ram[1])*1024:0,disk:disk?Number(disk[1])*1024:0,cpu:cpu?Number(cpu[1]||cpu[2]):cores?Number(cores[1])*100:0,swap:0,io:500};}
  function renderAuto(){const a=panelSettings.automation,t=a.template,root=$('auto-fields');root.replaceChildren();$('auto-enabled').checked=a.enabled;$('auto-adopt').checked=false;const fields=el('div','panel-fields');for(const [label,id,value,type]of [['Shared Egg ID','auto-egg',t.egg,'number'],['Shared Docker image','auto-image',t.docker_image,'text'],['Backup slots','auto-backups',t.feature_limits.backups,'number'],['Allocation slots','auto-allocations',t.feature_limits.allocations,'number'],['Database slots','auto-databases',t.feature_limits.databases,'number'],['Swap (MB; -1 = unlimited)','auto-swap',t.limits.swap,'number'],['I/O weight (10–1000)','auto-io',t.limits.io,'number']])fields.append(panelInput(label,value,id,type));const advanced=el('details','auto-advanced');advanced.append(el('summary','','Edit shared Egg, image & startup defaults'),fields,panelInput('Shared startup command',t.startup,'auto-startup'));root.append(advanced);const label=el('label','','Shared required Egg environment (JSON)'),input=el('textarea');input.id='auto-environment';input.rows=6;input.spellcheck=false;input.value=JSON.stringify(t.environment,null,2);label.append(input);advanced.append(label);const locations=el('div','panel-fields');for(const country of ['France','Germany','Singapore','United States'])locations.append(panelInput(country+' location ID (0 = unavailable)',t.locations[country]||0,'auto-location-'+country.replace(/ /g,'-'),'number'));root.prepend(el('p','auto-preset','Egg '+t.egg+' · '+t.docker_image+' · '+t.feature_limits.backups+' backups · '+t.feature_limits.allocations+' allocation slot(s)'),el('h4','','Shared panel locations — configure once'),locations);const count=Object.values(panelSettings.plans).filter(m=>m.autoManaged).length,issues=Object.values(panelSettings.plans).filter(m=>m.autoError).length;$('auto-summary').textContent=(issues?issues+' plans need explicit resource specs. ':'')+count+' plans currently use shared defaults. Examples: 100% CPU = one core; 5 GB RAM = 5120 MB. Replace conflicting spec lines instead of adding duplicates.';}
  function captureAuto(){const num=id=>{const v=Number($(id).value);if(!Number.isInteger(v))throw Error('Shared IDs and quotas must be whole numbers.');return v;},locations={};for(const country of ['France','Germany','Singapore','United States']){const id=num('auto-location-'+country.replace(/ /g,'-'));if(id<0)throw Error('Location IDs cannot be negative.');if(id>0)locations[country]=id;}return window.WavyPanelAuto.validate({enabled:$('auto-enabled').checked,template:{egg:num('auto-egg'),docker_image:$('auto-image').value.trim(),startup:$('auto-startup').value.trim(),environment:JSON.parse($('auto-environment').value),limits:{swap:num('auto-swap'),io:num('auto-io')},feature_limits:{backups:num('auto-backups'),allocations:num('auto-allocations'),databases:num('auto-databases')},locations}});}
  function renderMapping(){mappingPlan=$('panel-plan').value;const root=$('panel-mapping-fields');root.replaceChildren();const plan=planById(mappingPlan);if(!plan){root.append(el('p','','No Minecraft plans available.'));return;}const m=panelSettings.plans[mappingPlan],limits=m?.limits||defaultLimits(plan),enable=el('label','panel-map-toggle'),check=el('input');check.type='checkbox';check.id='map-enabled';check.checked=!!m&&!m.autoDisabled;enable.append(check,document.createTextNode(' Configure automatic delivery for this plan'));root.append(enable,el('p','panel-hint',plan.specs.join(' · ')));const shared=el('label','panel-bulk-toggle'),autoCheck=el('input');autoCheck.type='checkbox';autoCheck.id='map-auto';autoCheck.checked=!!m?.autoManaged;shared.append(autoCheck,document.createTextNode(' Use shared defaults for this plan (resources follow catalog specs)'));root.append(shared);if(m?.autoError)root.append(el('p','order-error',m.autoError));const fields=el('div','panel-fields');for(const [label,id,value,type]of [['Egg ID','map-egg',m?.egg||0,'number'],['Docker image','map-image',m?.docker_image||'','text'],['RAM (MB)','map-memory',limits.memory,'number'],['CPU limit (%)','map-cpu',limits.cpu,'number'],['Disk (MB)','map-disk',limits.disk,'number'],['Swap (MB; -1 means unlimited)','map-swap',limits.swap??0,'number'],['I/O weight (10–1000)','map-io',limits.io??500,'number']])fields.append(panelInput(label,value,id,type));root.append(fields);const startup=panelInput('Egg startup command',m?.startup||'','map-startup');root.append(startup);const env=el('label','','Required egg environment variables (JSON)'),textarea=el('textarea');textarea.id='map-environment';textarea.rows=4;textarea.spellcheck=false;textarea.value=JSON.stringify(m?.environment||{},null,2);env.append(textarea);root.append(env);const locations=el('div','panel-fields');for(const country of ['France','Germany','Singapore','United States'])locations.append(panelInput(country+' location ID (0 = unavailable)',m?.locations?.[country]||0,'map-location-'+country.replace(/ /g,'-'),'number'));root.append(el('h4','','Panel location IDs'),locations);const features=el('div','panel-fields');for(const [key,label]of [['databases','Database slots'],['allocations','Allocation slots'],['backups','Backup slots']])features.append(panelInput(label,m?.feature_limits?.[key]??(key==='allocations'?1:0),'map-feature-'+key,'number'));root.append(el('h4','','Feature quotas'),features,el('p','panel-hint','Save panel settings above to save this mapping too. A 5 GB plan uses 5120 MB, an 8 GB plan uses 8192 MB; 100% CPU is approximately one core.'));const lock=()=>{root.querySelectorAll('input:not(#map-enabled):not(#map-auto),textarea').forEach(e=>e.disabled=autoCheck.checked);};autoCheck.onchange=lock;lock();}
  function captureMapping(){if(!mappingPlan||!$('map-enabled'))return;if(!$('map-enabled').checked){panelSettings.plans[mappingPlan]={autoDisabled:true};return;}if($('map-auto')?.checked){panelSettings.plans[mappingPlan]={...panelSettings.plans[mappingPlan],autoManaged:true};return;}const num=id=>{const n=Number($(id).value);if(!Number.isInteger(n))throw Error('Resource limits and IDs must be whole numbers.');return n;},locations={};for(const country of ['France','Germany','Singapore','United States']){const id=num('map-location-'+country.replace(/ /g,'-'));if(id>0)locations[country]=id;}const environment=JSON.parse($('map-environment').value);if(!environment||typeof environment!=='object'||Array.isArray(environment))throw Error('Environment must be a JSON object.');const m={egg:num('map-egg'),docker_image:$('map-image').value.trim(),startup:$('map-startup').value.trim(),environment,limits:{memory:num('map-memory'),cpu:num('map-cpu'),disk:num('map-disk'),swap:num('map-swap'),io:num('map-io')},feature_limits:{},locations};for(const key of ['databases','allocations','backups'])m.feature_limits[key]=num('map-feature-'+key);if(m.egg<1||!m.docker_image||!m.startup||m.limits.memory<1||m.limits.disk<1||m.limits.cpu<0||m.limits.swap< -1||m.limits.io<10||m.limits.io>1000||!Object.keys(locations).length||Object.values(m.feature_limits).some(v=>v<0))throw Error('Complete the plan mapping with positive Egg/location IDs, valid limits, Docker image and startup.');panelSettings.plans[mappingPlan]=m;}
  function bulkSource(){if(!panelSettings)throw Error('Reload panel settings first.');if(!mappingPlan.startsWith('minecraft-intel-'))throw Error('Select an Intel Xeon Minecraft plan below. VPS and AMD plans are not included.');if(!$('map-enabled')?.checked)throw Error('Tick automatic delivery and complete the selected working plan first.');captureMapping();return panelSettings.plans[mappingPlan];}
  function bulkFingerprint(source){return JSON.stringify({sourceId:mappingPlan,source,plans:panelSettings.plans,catalog:catalog.plans['minecraft-intel'],overwrite:$('bulk-overwrite').checked});}
  function clearBulk(){bulkDraft=null;bulkSignature='';$('bulk-apply').disabled=true;$('bulk-preview-list').replaceChildren();}
  $('bulk-preview').onclick=()=>{clearBulk();try{const source=bulkSource();bulkDraft=window.WavyPanelBulk.prepare(catalog,panelSettings.plans,mappingPlan,source,$('bulk-overwrite').checked);bulkSignature=bulkFingerprint(source);const table=el('table'),caption=el('caption','','Intel Xeon Minecraft mappings — resource limits per server');table.append(caption);const head=el('thead'),tr=el('tr');for(const title of ['Plan','RAM (MB)','CPU (%)','Disk (MB)','Action'])tr.append(el('th','',title));head.append(tr);table.append(head);const tbody=el('tbody');for(const row of bulkDraft.rows){const tr=el('tr');for(const value of [row.name,row.memory,row.cpu,row.disk,row.action])tr.append(el('td','',String(value)));tbody.append(tr);}table.append(tbody);$('bulk-preview-list').append(table);$('bulk-feedback').textContent=bulkDraft.changed+' Intel Minecraft mappings will change. Existing mappings are '+($('bulk-overwrite').checked?'included.':'preserved. Enable the checkbox if you want to update them too.');$('bulk-apply').disabled=!bulkDraft.changed;}catch(e){clearBulk();$('bulk-feedback').textContent=e.message;}};
  $('bulk-apply').onclick=()=>{try{if(!bulkDraft)throw Error('Preview the setup first.');const source=bulkSource();if(bulkFingerprint(source)!==bulkSignature){clearBulk();throw Error('Settings changed after the preview. Preview again before applying.');}const count=bulkDraft.changed;panelSettings.plans=bulkDraft.plans;clearBulk();renderMapping();$('bulk-feedback').textContent=count+' Intel Minecraft mappings applied to the draft. Click Save panel settings above to persist them. No server was created or changed.';$('panel-feedback').textContent='Unsaved bulk setup: click Save panel settings.';}catch(e){$('bulk-feedback').textContent=e.message;}};
  $('bulk-overwrite').onchange=()=>{clearBulk();$('bulk-feedback').textContent='Preview again after changing the update option.';};
  async function loadPanel(){try{clearBulk();$('bulk-feedback').textContent='Select a working Intel Minecraft plan below, then preview. Save panel settings to persist changes.';panelSettings=(await api('/api/admin/panel')).settings;renderAuto();$('panel-url').value=panelSettings.panelUrl;$('panel-key').value='';$('panel-enabled').checked=panelSettings.enabled;$('panel-demo-enabled').checked=panelSettings.demoEnabled===true;$('panel-demo-capacity').value=panelSettings.demoMaxConcurrent??10;$('panel-clear-key').checked=false;$('panel-existing-users').value=JSON.stringify(panelSettings.existingUsers,null,2);$('panel-key-state').textContent=panelSettings.keyPresent?'Key saved privately ('+panelSettings.keySource+'). It will never be shown here.':'No saved Application API key.';const select=$('panel-plan');select.replaceChildren();for(const [group,plans]of Object.entries(catalog.plans)){if(!group.startsWith('minecraft-'))continue;for(const p of plans){const op=el('option','',group+' / '+p.name+' · '+p.id);op.value=p.id;select.append(op);}}if(planById(mappingPlan))select.value=mappingPlan;renderMapping();$('panel-feedback').textContent='';}catch(e){$('panel-feedback').textContent=e.message;}}
  $('panel-plan').addEventListener('change',()=>{try{captureMapping();clearBulk();renderMapping();}catch(e){$('panel-plan').value=mappingPlan;$('panel-feedback').textContent=e.message;}});
  $('panel-settings-form').addEventListener('submit',async e=>{e.preventDefault();const btn=e.submitter;btn.disabled=true;try{if(!panelSettings)throw Error('Reload panel settings first.');captureMapping();const key=$('panel-key').value.trim();if(key&& !key.startsWith('ptla_'))throw Error('Use an Application API key (ptla_). Client keys (ptlc_) cannot create users/servers.');const result=await api('/api/admin/panel','PUT',{revision:panelSettings.revision,panelUrl:$('panel-url').value.trim(),enabled:$('panel-enabled').checked,demoEnabled:$('panel-demo-enabled').checked,demoMaxConcurrent:Number($('panel-demo-capacity').value),apiKey:key,clearKey:$('panel-clear-key').checked,plans:panelSettings.plans,automation:captureAuto(),adoptExisting:$('auto-adopt').checked,existingUsers:JSON.parse($('panel-existing-users').value)});panelSettings=result.settings;$('panel-key').value='';await loadPanel();$('panel-feedback').textContent='Panel settings and shared defaults saved. New Minecraft plans now map themselves when published. Test the connection before approving a paid order.';}catch(e){$('panel-key').value='';$('panel-feedback').textContent=e instanceof SyntaxError?'Invalid JSON in environment or existing-account links.':e.message;}finally{btn.disabled=false;}});
  $('panel-test').addEventListener('click',async()=>{$('panel-test').disabled=true;$('panel-feedback').textContent='Testing read-only Application API access…';try{$('panel-feedback').textContent=(await api('/api/admin/panel/test','POST',{})).message;}catch(e){$('panel-feedback').textContent=e.message;}finally{$('panel-test').disabled=false;}});$('panel-reload').addEventListener('click',loadPanel);
  async function loadDatabase(){try{const b=await api('/api/admin/database');$('database-state').textContent=b.integrity==='ok'?'✅ SQLite healthy · Restart-safe storage':'❌ Database integrity needs attention';$('database-details').replaceChildren();for(const [label,value]of [['File',b.databaseFile],['Data folder',b.dataDirectory],['Records',b.counts.customers+' customers · '+b.counts.orders+' orders'],['Durability',b.journalMode+' / '+b.durability],['Size',(b.bytes/1024).toFixed(1)+' KB']]){const box=el('div');box.append(el('dt','',label),el('dd','',value));$('database-details').append(box);}}catch(e){$('database-state').textContent=e.message;}}
  $('database-refresh').onclick=loadDatabase;
  $('database-backup').onclick=async()=>{const button=$('database-backup');button.disabled=true;$('database-feedback').textContent='Preparing private backup…';try{const r=await fetch('/api/admin/database-backup',{headers:{'X-CSRF-Token':csrf}});if(!r.ok){const b=await r.json();throw Error(b.error||'Backup failed.');}const url=URL.createObjectURL(await r.blob()),link=el('a');link.href=url;link.download='wavy-cloud-backup-'+new Date().toISOString().slice(0,10)+'.sqlite';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);$('database-feedback').textContent='✅ Backup downloaded. Keep this private file in a secure location.';}catch(e){$('database-feedback').textContent=e.message;}finally{button.disabled=false;}};
  async function start() {
    try {
      const s = await api('/api/admin/session'); csrf = s.csrf;
      catalog = await api('/api/catalog');
      $('login-panel').hidden = true; $('dashboard').hidden = false; $('logout').hidden = false;
      render();loadDatabase();
    } catch(e) {
      $('login-panel').hidden = false; $('dashboard').hidden = true;
      $('login-feedback').textContent = e.message;
    } finally { $('loading').hidden = true; }
  }
  $('admin-login-form').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.currentTarget, btn = form.querySelector('button');
    btn.disabled = true;
    try {
      await api('/api/admin/login', 'POST', {
        email:form.elements.email.value.trim(), password:form.elements.password.value,
        remember:form.elements.remember.checked
      });
      form.elements.password.value = ''; await start();
    } catch(e) { $('login-feedback').textContent = e.message; }
    finally { btn.disabled = false; }
  });
  $('logout').addEventListener('click', async () => {
    if (dirty && !confirm('Log out and discard unpublished changes?')) return;
    try { await api('/api/admin/logout','POST',{}); dirty = false; location.href = 'index.html'; }
    catch(e) { $('feedback').textContent = e.message; }
  });
  $('save').addEventListener('click', async () => {
    if (saving) return;
    saving = true; $('save').disabled = true; $('feedback').textContent = 'Publishing…';
    try {
      catalog = await api('/api/admin/catalog', 'PUT', catalog);
      dirty = false; $('save-state').textContent = 'All changes saved';
      $('save-state').style.color = '#abdcc6';
      $('feedback').textContent = 'Published successfully. Refresh the website to see your changes.';
      render();loadDatabase();
    } catch(e) { $('feedback').textContent = e.message; }
    finally { saving = false; $('save').disabled = false; }
  });
  document.querySelectorAll('[data-view]').forEach(btn=>btn.addEventListener('click',()=>{view=btn.dataset.view;if(btn.dataset.service)service=btn.dataset.service;render();}));
  $('refresh-users').addEventListener('click',loadUsers);$('refresh-orders').addEventListener('click',loadOrders);$('order-filter').addEventListener('change',renderOrders);
  $('plan-family').addEventListener('change', renderPlans);
  $('add-plan').addEventListener('click', () => {
    const plans = catalog.plans[service + '-' + family];
    if (plans.length >= 100) { alert('Maximum 100 plans per family.'); return; }
    const random = globalThis.crypto?.randomUUID?.() || Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
    plans.push({
      id:service + '-' + family + '-' + random, name:'New plan', price:0, type:'CUSTOM',
      description:'Describe this hosting plan.', button:'Choose plan',
      specs:['4 GB RAM','2 processor cores','30 GB NVMe storage'], popular:false, offer:''
    });
    changed(); renderPlans();
    $('plan-editors').lastElementChild.querySelector('details').open=true;
    $('plan-editors').lastElementChild.scrollIntoView({behavior:'smooth',block:'center'});
  });
  $('password-form').addEventListener('submit', async e => {
    e.preventDefault(); const form = e.currentTarget;
    try {
      await api('/api/admin/password', 'POST', {
        current:form.elements.current.value, password:form.elements.password.value
      });
      form.reset(); $('password-feedback').textContent = 'Password updated. Other admin sessions were signed out.';
    } catch(e) { $('password-feedback').textContent = e.message; }
  });
  window.addEventListener('beforeunload', e => {
    if (dirty) { e.preventDefault(); e.returnValue = ''; }
  });
  await start();
})();