(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.WavyPricing=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 function offerPercent(text){const match=String(text||'').match(/([+-]?\d+(?:\.\d+)?)\s*%/);if(!match)return 0;const n=Number(match[1]);return Number.isFinite(n)&&n>=0&&n<=100?n:0;}
 function price(plan){const baseCents=Math.round(Number(plan.price)*100),discountPercent=offerPercent(plan.offer),unitCents=Math.round(baseCents*(100-discountPercent)/100);return {baseCents,unitCents,discountPercent,basePrice:baseCents/100,unitPrice:unitCents/100,savingCents:baseCents-unitCents};}
 const money=cents=>'$'+(cents/100).toFixed(2);
 return {offerPercent,price,money};
});
