# Historical installation notes

This complete v24 ZIP already merges the earlier releases. Follow INSTALL-V24.md or START-HERE.md.
