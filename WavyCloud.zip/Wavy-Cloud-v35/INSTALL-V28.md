# Wavy Cloud v28 — focused theme fixes

## Changes
- Light-mode hero: reduced the white overlay so the background image is visible, with dark text for readability.
- Removed the background name, scene dots and Pause/Play controls in both themes. Automatic background transitions remain; reduced-motion preferences are respected.
- The regions/map card and closing “Make something worth logging into” card now use dark surfaces in dark mode. Light mode remains light.
- Backend, orders, accounts, panel automation and catalog features from v27 are unchanged.

## Existing installation
Back up your existing application and private data first. For this UI-only update, replace `index.html`, `css/index.css` and `script/hero-scenes.js` from this archive. No database migration is needed. Keep your existing `.env`, DATA_DIR, database, keys and server configuration unchanged. Restart only if required by your deployment, then hard-refresh the browser (Ctrl+Shift+R).

## Fresh installation
Use Node.js 24 LTS. Run `npm ci`, configure your own environment as described in `.env.example`, then run `npm start`. See INSTALL-V27.md and INSTALL-V26.md for backend and persistent-storage setup. Do not run the hosting application by opening HTML files directly.

No real credentials or customer database are included in this archive.
