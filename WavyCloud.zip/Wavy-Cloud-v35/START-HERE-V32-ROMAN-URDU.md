# v32 — sirf do requested changes

## Update

1. Website aur private DATA_DIR/database ka backup lo.
2. v32 ki application files deploy karo. **Apni `.env`, SQLite database, DATA_DIR, panel keys aur payment settings mat badalna.** Changed files ki list `INSTALL-V32.md` mein hai. Dono nayi files `demos.js` aur `script/demos.js` lazmi upload karna.
3. **Backend restart** karo, phir **Ctrl+Shift+R**.

## Remove button

My order requests mein Pending, Suspended aur panel se verified Deleted services par Remove milega. Ye sirf user ki list se hatata hai; admin record, receipt/payment evidence aur panel server delete nahi hota. Active ya unverified services remove nahi hongi. Agar admin baad mein service active restore kare to card dobara nazar aayega.

## 30-minute demo enable karo

Admin → **Panel API** mein:

- Application API ki Users/Servers **Read & Write** permissions aur panel connection sahi rakho.
- Shared Minecraft defaults mein asli Egg, image/startup/environment aur location IDs ek baar configure karo.
- **Enable 30-minute Minecraft demos** check karke **Save panel settings** dabao.

User Create demo server par click karke sign in/register karega, naam/location aur permanent deletion ki confirmation dega. Demo: **2 GB RAM, 100% CPU, 5 GB disk**, free; ek account ka ek trial har 24 ghante aur poori site par maximum 3 demos.

30-minute timer pehli creation request se shuru hota hai; installation/setup time bhi isi mein count hota hai. Retry se timer extend nahi hota. Time poora hone par website management band hoti hai, backend pehle demo suspend karta hai aur phir uska server/files permanently delete karta hai. Paid servers aur panel user account delete nahi hote.

**Backend chalta rehna aur panel reachable hona zaroori hai.** Agar website backend band ho ya panel offline ho, usi second deletion ki guarantee nahi; cleanup restart/reconnection ke baad automatic retry hoti hai. Demo files ko permanent samajh kar data mat rakho.

Payments & coupons mein koi naya change nahi kiya gaya. Pehle ek test demo apne actual panel par check kar lena.
