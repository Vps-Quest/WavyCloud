# Wavy Cloud v31 — payments, coupons and protected checkout

## Upgrade from v30

Back up the application and private DATA_DIR first. Preserve your existing `.env`, SQLite database, DATA_DIR, catalog, panel settings and encryption keys. Do not reset or replace private data.

Deploy the full application code, or replace/add these files together:

- `server.js`, **NEW `payments.js`**
- `index.js`, `checkout.html`, `admin.html`
- `script/account.js`, `script/commerce.js`, `script/checkout.js`, `script/admin.js`
- **NEW `script/theme-icon.js`**
- `css/index.css`, `css/checkout.css`, `css/admin.css`
- `package.json`, `package-lock.json` for version metadata (dependencies unchanged)

**Restart the Node backend**, then Ctrl+Shift+R. Node.js 24 LTS recommended; minimum 22.13. HTML-only hosting cannot save settings or proofs. New payment settings and proof images are stored privately in the existing SQLite documents store; no database reset is required. Backups contain sensitive customer data and images, so protect them.

## Payment configuration

Open **Admin → Payments & coupons**, edit settings, then **Save payments & coupons**.

- Each method supports **Available / Coming soon**. Coming-soon methods are disabled in checkout and rejected by the backend.
- Card starts Coming soon. Available enables manual instructions/order requests only, **not a card gateway**. No card number, CVV, wallet PIN or OTP is collected.
- As confirmed by the owner, Easypaisa and JazzCash initially use the screenshot details: **Faysal DigiBank / Shazia Ashraf / 0301-5870372**. Verify these before accepting live transfers. Bank, account holder, number, method label and instructions are editable separately for both wallets.
- Paste your **real HTTPS Discord invitation URL** for UPI. It is blank on a clean installation; no example invite is shipped. Until configured, the popup asks customers to contact support.
- Prices remain USD. No exchange rate or PKR/INR conversion is invented. Confirm actual payable currency and amount through support/instructions before any transfer.
- Coupons start empty. Add a code such as `SAVE20`, discount `20`, enable it and save. Codes support letters, numbers, hyphens and underscores, are case-insensitive, unique and 2–32 characters. Percentages must be above 0 and up to 100.
- Coupons work across Minecraft/VPS products and quantities, **after existing plan offers**, rounded to cents. Example: $6 less a 20% plan offer = $4.80; a further 20% coupon = $3.84. Backend recalculates totals and validates the coupon at submission. This is a saved monthly quote, not an automated recurring billing system.

## Checkout and proof

Continue to checkout checks the customer session. Guests see registration/sign-in first, retaining their local cart; successful authentication returns them to checkout. Direct checkout access and the order API also require a customer account.

No payment method is preselected or restored. Selecting a method opens its instructions. Close via Got it, close button, Escape or backdrop; View payment instructions reopens it.

Easypaisa/JazzCash require **sender account name, transaction ID and screenshot**. PNG/JPG/WebP up to **2 MB** are accepted. Server name/location unlock after all three fields are present, and the backend checks proof fields, type and size before saving.

Submission remains **Pending / Not processed**. A screenshot never automatically marks payment Paid or starts delivery. In **Admin → Orders → Manage order / payment**, inspect sender name, transaction ID, coupon/savings and **View payment screenshot**. Only the signed-in order owner or an administrator can access the image endpoint. Proof images are not exposed in static folders or ordinary order-list payloads.

Independently verify the transfer and amount, then use **Successful + Paid** approval as before. The website does not verify transaction IDs with a bank/wallet API. Existing panel lifecycle controls, setup, receipt and service pages are retained.

## Delivery notice and theme

The home notice reads “📦 Your product has been delivered! ✅”, closes after **20 seconds** and can be dismissed manually. It does not return at the next polling interval or reload in the same tab session. Receipts and Manage service remain available.

Checkout/admin now use sun/moon SVG icons with the existing shared theme preference. Wallet/UPI popups support light/dark themes and mobile screens.

## Automatic Minecraft mapping

The existing v27+ automatic-mapping workflow remains in place and is regression tested. In **Panel API → Automatic Minecraft defaults**, enable automatic mapping and configure your real panel location IDs once. Shared defaults include Egg 1, Java 25 image, startup/environment, 5 backups and 1 allocation; verify that your panel supports them.

New Minecraft plans for Intel, EPYC or Ryzen automatically receive mappings on publish when specs are explicit, for example `8 GB RAM`, `400% CPU` (or `4 processor cores`), `50 GB NVMe storage`. These map to 8192 MB RAM, 400% CPU and 51200 MB disk. Shared Egg/image/startup/environment are reused. Publishing does not create a real server; delivery still requires Successful + Paid.

Existing manual overrides/opt-outs are preserved. Use “Apply these defaults to all existing Minecraft mappings too” only when you intend to adopt existing mappings. VPS remains manual fulfilment, not automatic Pterodactyl VPS creation.

## Validation

98 automated backend tests passed, including payment availability, CSRF/ownership, required wallet proofs, private image access, mixed-product coupon calculations, disabled coupons, tampered totals, persistence and existing panel delivery behavior. Local browser checks cover responsive light/dark checkout and popups, registration/cart redirects, coupon use, proof submission, admin settings and notification expiry.

Panel integration tests use a mock panel, not your live service. Run one small customer/payment/panel test before rollout. No real customer database, credentials, preview coupons or preview Discord invite is bundled.
