# Wavy Cloud v26 — durable data, clearer orders, smoother overlays

Based on the supplied v24 build. The v24 blue theme, plans, admin tools and panel workflows are retained.

## Requirements

- **Node.js 22.13 or newer; Node.js 24 LTS recommended.** SQLite is built into Node; no separate database service is required.
- A Node backend with a **persistent, writable local disk**. Static hosting or opening index.html directly cannot save accounts/orders.
- Run **one website process** per data directory. This build is not a multi-instance/cluster backend.

## Start

```sh
npm ci --omit=dev
npm start
```

Windows: install Node.js 24 LTS and open `START-WEBSITE.bat`.

Website: http://localhost:3000 — Admin: http://localhost:3000/admin.html.

The existing first-run admin defaults remain `admin@gmail.com` / `admin`. Change the password before going public. In production, the backend refuses this default password.

The old static GitHub Pages workflow is preserved as `.github/static-pages-v24.yml.disabled`, not an active deployment. The active workflow now runs backend tests on Node 24. GitHub Pages cannot run this database backend; use Node hosting with persistent storage.

## The important persistence setting

By default data is stored in `private-data` beside server.js. The startup log and Admin → Home settings → Database show the exact active folder.

For hosting/upgrades, set a stable location **outside the replaceable website folder**:

```sh
DATA_DIR=/srv/wavy-cloud-data npm start
```

You may copy `.env.example` to `.env` and set DATA_DIR there. Environment variables take precedence. Never publish `.env`.

For a container, mount a persistent volume and point DATA_DIR to its mount path. On hosts with ephemeral filesystems, a restart/redeploy can erase SQLite just as it can erase JSON. **The code cannot retain data if the host removes its storage.** Do not delete, empty or recreate the data folder during upgrades.

## Upgrade from v24 (preserve your data)

1. Stop the old website process.
2. Back up the old **entire private-data folder**, including `pterodactyl.json` and `panel-secret.key` if present. Keep it private.
3. Put v26 in a separate website folder. Do not overwrite/remove the old data folder.
4. Set v26's DATA_DIR to the old data folder's absolute path, then start v26.
5. The backend imports existing catalog, admin password hash, customers, orders, notifications, panel settings and encryption key into `wavy-cloud.sqlite` in one transaction.
6. Check customers, order history and Admin → Database before retiring the old code.

Legacy JSON files are left untouched as pre-migration copies. After migration **SQLite is authoritative**; editing those JSON files does not change the running website. Do not run v24 and v26 against the same data directory simultaneously.

If an old data file is malformed, startup fails rather than silently replacing it with an empty list. Fix/restore the original data from a trusted backup. Data already erased by a previous deployment cannot be reconstructed from nothing.

## Database files

- `wavy-cloud.sqlite`: durable documents, panel encryption material and website sessions.
- `wavy-cloud.sqlite-wal`, `wavy-cloud.sqlite-shm`: SQLite-managed sidecars while running. Do not delete them or copy only the main file while the server is running.
- `database-schema.sql`: reference schema in the source package; storage.js initializes the actual database automatically.

Writes use SQLite transactions with WAL and FULL synchronization. Website login sessions survive a backend restart until their original expiry (8 hours, or 7 days with Remember me); logging out/revoking an account/password change still invalidates the relevant sessions. Existing v24 logins may need one fresh sign-in after upgrading.

Customer and admin passwords remain scrypt hashes. Panel tokens remain encrypted. The encryption key is in the private database so a complete downloadable database backup can restore panel access. The database and its backups are **sensitive secrets**, not public attachments.

## Back up

Admin → Home settings → Database → **Download database backup**.

This creates a consistent standalone SQLite snapshot with customer records, order history, catalog, admin password hash and saved panel settings/encryption material. Browser login sessions are excluded. Download requires an authenticated admin and the session security token.

Environment-only SMTP/Pterodactyl keys and .env configuration are not inside the SQLite download. Preserve them separately in secure storage.

Keep dated copies in a secure location separate from the hosting machine. Back up before upgrades. If using raw folder copies instead, stop the server first and back up the entire data folder.

## Restore a downloaded backup

1. Stop all website processes. Do not restore over a running SQLite database.
2. Preserve/rename the current entire data folder as a rollback copy.
3. Create a **new empty data folder** on persistent storage.
4. Copy the downloaded backup there with the name `wavy-cloud.sqlite`. Do not copy the previous database's WAL/SHM files into this new folder.
5. Set DATA_DIR to this new folder, restart, and sign in using the credentials in that backup. Browser sessions from the old database do not carry over.
6. Check Admin → Database, customers, orders and the panel's Test connection. Only resume real approvals after validation.

Never restore a database from an untrusted source.

## Interface/performance changes

- Pending ⏳, active ✅, suspended ⛔, expired ⌛ and setup errors ❌ have text labels, not color alone.
- Order overview, service icons, progress and clearer request/receipt actions.
- Checkout confirmation clearly says the request was saved; it is not a payment receipt.
- Full-viewport modal blur removed; overlay dimming and all features remain.
- Decorative animations pause behind overlays, off-screen and in hidden tabs.
- Cart avoids unnecessary unchanged redraws; delivery notifications no longer rebuild on every poll.
- Orders refresh every 15 seconds while visible; manual Refresh remains available.

## Verification

```sh
npm test
```

The suite includes registration, privacy, order approval/panel workflows, legacy migration, encryption-key continuity, session revocation, backup restoration and abrupt-process-restart durability. Automated panel tests use local fixtures, not real customer servers.
