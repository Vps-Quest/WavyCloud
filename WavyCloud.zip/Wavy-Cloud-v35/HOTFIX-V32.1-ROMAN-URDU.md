# v32.1 — Demo location dropdown fix

## Masla aur fix
v32 mein authenticated GET /api/account/demos security-token gate ke baad tha. Frontend is read-only request par token nahi bhej raha tha, is liye locations ki jagah 403 security error aa raha tha.

- Read-only availability GET ab account login check ke baad aur mutation CSRF gate se pehle hai, baqi account read endpoints ki tarah.
- Frontend compatibility ke liye GET par bhi current CSRF token bhejta hai.
- Demo create karne se foran pehle session dobara load hota hai, taake doosre tab mein login badalne se purana token istemal na ho.
- Demo creation POST par login, CSRF aur rate limits barqarar hain.
- Location loading/error par dropdown disabled aur wazeh placeholder hota hai; successful response par real configured locations load hoti hain. Koi fake France location ID add nahi ki gayi.

## Upgrade
1. Apni .env aur existing persistent database / DATA_DIR ka backup lo aur unhein preserve rakho.
2. Full merged files update karo. Is hotfix ke main changed runtime files: server.js aur script/demos.js.
3. Node backend zaroor restart karo.
4. Browser mein Ctrl+Shift+R karo; agar purana session error rahe to sign out karke sign in karo.
5. Admin → Panel API mein automatic delivery aur 30-minute demos enabled hon; Application API key, shared Minecraft Egg/image/startup/environment aur real location ID mapping save honi chahiye. France ka numeric panel location ID guess mat karo.
6. Agar message kahe ke trials/location configure nahi hain, real saved configuration theek karo. Sirf dropdown label add karne se panel server nahi banega.

## Testing
120 automated tests pass. Real local website backend + browser regression mein France/Germany dropdown loading, France selection, dialog khula rehne ke dauran session rotation, fresh-token POST aur mock panel mein actual server creation verify hua. Browser API responses mock nahi kiye gaye. Tumhare live Pterodactyl panel par test nahi hua.

Payments/coupons aur demo ke 30-minute suspend → delete rules is hotfix mein change nahi hue. Backend/panel outage mein cleanup available hone par retry hota hai; offline hon to exact-second deletion mumkin nahi.
