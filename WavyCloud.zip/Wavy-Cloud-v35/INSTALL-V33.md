# v33 deployment and behavior

This is the complete merged application, including the v32.1 location/session fix. Read START-HERE-V33-ROMAN-URDU.md first.

## Changed runtime files since v32.1
- server.js: full-slot response includes current availability.
- demos.js: configured concurrency enforcement and durable aggregate slot status; no changes to the fixed 30-minute deadline.
- pterodactyl.js: saved demoMaxConcurrent (integer 1–100, default 10).
- admin.html, script/admin.js, css/admin.css: Maximum concurrent demos field in Panel API.
- script/demos.js, css/index.css: full-slot estimate + polling/manual check, in-dialog panel-account setup, success countdown and panel/service links.
- script/orders.js: demo-specific registration completion message for resumed setup.

Preserve .env and the existing persistent DATA_DIR/SQLite database and encryption material. No reset or destructive migration is required. Deploy all files, npm ci, restart Node, hard-refresh browsers. Configure the limit and save Panel API settings. Resource template/location IDs and Users/Servers Application API write permissions remain required.

Each non-deleted demo reserves one slot, including setup failures, hidden entries, expiry and cleanup retries. Verified deletion releases its slot. Lowering the cap never terminates existing demos. Increasing it permits additional trials immediately. No user-visible queue position or reserved turn is claimed. The browser polls every ten seconds; slot acquisition is enforced by the backend, not the displayed estimate.

New demo owners use the existing verified Application API account provisioning. An in-dialog form updates that same account with the user's chosen username/password after website-password and CSRF verification. Existing configured accounts bypass unnecessary registration. Existing externally linked users are directed to the existing ownership-aware service flow; their passwords are not silently reset. Setup can be resumed on the demo service page. No secrets are persisted in localStorage or registration snapshots.

The trial deadline starts with initial creation, includes installation and registration, and does not extend. Expiry cleanup suspends and verifies then deletes only the owned demo server. It does not delete panel users or website users. Offline backend/panel can delay cleanup; original deadlines survive restarts, and cleanup retries. Hosting capacity must independently support the configured cap and fixed resources (2048 MB RAM, 100% CPU, 5120 MB disk per trial).

133 automated tests pass, including simultaneous 10/11 requests, cap validation and persistence, lowering/increasing limits, restart accounting, failed-cleanup slot retention, slot reuse, first-time panel-account creation, chosen-login setup, same-account ownership, unchanged deadline and retained panel user after cleanup. Real browser tests use the actual local website API, not mocked browser responses; the external Pterodactyl API is a fixture, not the customer's live panel.
