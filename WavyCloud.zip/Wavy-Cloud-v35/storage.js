'use strict';
// DATA_DIR must be on a persistent disk/volume, with one website instance.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
let DatabaseSync;try{({DatabaseSync}=require('node:sqlite'));}catch(_){throw Error('Wavy Cloud v26 requires Node.js 22.13+ (Node.js 24 LTS recommended).');}
module.exports=function(dataDir){
 fs.mkdirSync(dataDir,{recursive:true,mode:0o700});
 const filename=path.join(dataDir,'wavy-cloud.sqlite'),db=new DatabaseSync(filename);fs.chmodSync(filename,0o600);
 db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS documents (name TEXT PRIMARY KEY, data TEXT NOT NULL CHECK(json_valid(data)), updated_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS sessions (kind TEXT NOT NULL, token TEXT NOT NULL, data TEXT NOT NULL CHECK(json_valid(data)), expires INTEGER NOT NULL, PRIMARY KEY(kind,token));
 PRAGMA user_version=1;`);
 const read=db.prepare('SELECT data FROM documents WHERE name=?'),write=db.prepare('INSERT INTO documents(name,data,updated_at) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET data=excluded.data,updated_at=excluded.updated_at');
 const key=file=>path.basename(file);
 function persist(file,obj){write.run(key(file),JSON.stringify(obj),new Date().toISOString());}
 function load(file,initial){const row=read.get(key(file));if(row)return JSON.parse(row.data);const value=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):initial;persist(file,value);return value;}
 // Import legacy data atomically. Existing database rows always take precedence.
 db.exec('BEGIN IMMEDIATE');try{for(const name of ['catalog.json','admin.json','users.json','orders.json','notifications.json','pterodactyl.json']){const f=path.join(dataDir,name);if(fs.existsSync(f)&&!read.get(name))load(f,null);}const legacyKey=path.join(dataDir,'panel-secret.key');if(fs.existsSync(legacyKey)&&!read.get('panel-secret.key')){const value=fs.readFileSync(legacyKey);if(value.length!==32)throw Error('Invalid legacy panel encryption key.');persist(legacyKey,{hex:value.toString('hex')});}db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');db.close();throw e;}
 function encryptionKey(){const f=path.join(dataDir,'panel-secret.key');let row=read.get(key(f));if(!row){persist(f,{hex:crypto.randomBytes(32).toString('hex')});row=read.get(key(f));}const value=JSON.parse(row.data).hex;if(!/^[a-f0-9]{64}$/.test(value||''))throw Error('Invalid stored panel encryption key.');return Buffer.from(value,'hex');}
 class SessionMap extends Map{
  constructor(kind){super();this.kind=kind;db.prepare('DELETE FROM sessions WHERE expires<=?').run(Date.now());for(const row of db.prepare('SELECT token,data FROM sessions WHERE kind=?').all(kind))super.set(row.token,JSON.parse(row.data));}
  set(token,value){db.prepare('INSERT OR REPLACE INTO sessions(kind,token,data,expires) VALUES(?,?,?,?)').run(this.kind,token,JSON.stringify(value),value.expires);return super.set(token,value);}
  delete(token){if(token!==undefined)db.prepare('DELETE FROM sessions WHERE kind=? AND token=?').run(this.kind,token);return super.delete(token);}
 }
 function info(){return {engine:'SQLite',schemaVersion:1,databaseFile:'wavy-cloud.sqlite',dataDirectory:dataDir,journalMode:'WAL',durability:'FULL',integrity:db.prepare('PRAGMA quick_check').get().quick_check,bytes:fs.statSync(filename).size+(['-wal','-shm'].reduce((n,s)=>n+(fs.existsSync(filename+s)?fs.statSync(filename+s).size:0),0))};}
 function backup(){const out=path.join(dataDir,'.backup-'+crypto.randomUUID()+'.sqlite');try{db.prepare('VACUUM INTO ?').run(out);fs.chmodSync(out,0o600);const copy=new DatabaseSync(out);try{copy.exec('DELETE FROM sessions; PRAGMA journal_mode=DELETE;');}finally{copy.close();}return fs.readFileSync(out);}finally{fs.rmSync(out,{force:true});}}
 function transaction(fn){db.exec('BEGIN IMMEDIATE');try{const result=fn();db.exec('COMMIT');return result;}catch(e){db.exec('ROLLBACK');throw e;}}
 return {transaction,persist,load,encryptionKey,sessionMap:kind=>new SessionMap(kind),info,backup,close:()=>db.close()};
};
