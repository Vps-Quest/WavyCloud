# Wavy Cloud v30 — first-time panel setup and dedicated service pages

## Upgrade from v29

Back up the application and private DATA_DIR first. This update changes the service frontend, not the backend or database schema.

Replace/add these files together:

- `orders.html` — updated service/receipt page and matching theme button
- `connect-server.html` — NEW dedicated Client-key, live status, power and console page
- `forgot-password.html` — NEW dedicated panel password page
- `script/orders.js` — shared, authenticated service frontend
- `css/orders.css` — shared service-page styling
- Optionally replace `package.json` and `package-lock.json` for version 30 metadata; dependencies are unchanged.

Keep your existing `.env`, DATA_DIR, database, panel settings, encryption keys, customer records and catalog. Do not replace private data with an empty directory. No database reset or migration is needed. Continue running the Node backend; HTML files are not a standalone application.

On a running v29 Node server, these static files are read per request. Restart your deployment if it caches/bundles the application, then hard-refresh the browser (Ctrl+Shift+R). Deploy BOTH new HTML files; updating only the script would leave broken links.

If upgrading from an older version, deploy the full application code with your SAME private data/environment. See INSTALL-V29.md and INSTALL-V26.md for the backend lifecycle and persistent-storage setup.

## New-customer flow

1. After a successful paid delivery, open **My order requests → Manage service**.
2. Active status, Print receipt and Order details & receipt remain visible.
3. Immediately below that summary, **Complete panel registration** is expanded for an account whose `setupComplete` is false. The page scrolls/focuses to it on first entry, instead of leaving the registration form hidden behind another action.
4. Confirm the website password, choose the panel username/password and finish setup using the existing verified account endpoint. This configures the already-created panel account; it does NOT create a duplicate panel account.
5. Success shows a clear confirmation and **Connect your server →**, which navigates to the separate HTML page.
6. Once the account is set up, the first-time registration form is no longer displayed on Orders. It is one setup per linked panel account, not a new registration for every service.

## Real page navigation

- **Connect your server** opens `connect-server.html?manage=<order ID>`. API instructions/key connection, live overview, power and console commands live there, not on Orders.
- **Forgot password** opens `forgot-password.html?manage=<order ID>`. It preserves the existing panel password/update and panel email-reset tools, without rendering the server console or receipt on that page.
- Both pages have a **Back to service** link. Native links support normal browser navigation and opening a new tab.
- Opening Connect before the initial setup is complete shows a link back to the visible registration form; it does not bypass the setup flow.
- All pages still load only the signed-in customer's orders. A missing/foreign order shows no service controls. Revoked services retain receipt-only access; no suspended/deleted server controls are created.

## Theme and delivery indicators

Orders and both task pages use a lightweight, borderless sun/moon theme control styled like the main site's toggle. They share the existing `wavy-theme` preference with the main site; icons reflect the current theme. The icon uses inline SVG so it does not depend on a remote icon font.

Delivered active services have a restrained **📦 / ✅** confirmation and a next-step message. No continuous decorative animation was added. The delivery marker does not override suspended/deleted status.

## Validation

- 88 automated backend tests passed; the v29 lifecycle, ownership, CSRF, command and receipt safeguards are unchanged.
- 17 browser workflow checks passed, covering first-time registration placement/focus, completing setup, real HTML navigation, Connect setup gating, API key connection, sending a console command, separate password completion, main-site theme persistence, responsive widths, suspended-service receipt-only access and signed-out access.
- Desktop/mobile and dark/light sample screens, including setup/password success states, were visually inspected.

Browser integration checks use safe mocked customer/panel data, not your live panel. Verify the upgraded flow with one test customer before rollout. No real credentials or customer database are included.
