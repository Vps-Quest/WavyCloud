# Wavy Cloud v26 — पहले यह पढ़ें

## पुराना डेटा बचाने के लिए
1. पुरानी website बंद करें और उसकी पूरी `private-data` folder की backup copy रखें।
2. नई ZIP को अलग folder में extract करें। पुरानी data folder delete/replace नहीं करनी है।
3. `.env.example` की copy `.env` नाम से बनाएँ और DATA_DIR में पुरानी data folder का पूरा path दें। Windows पर forward-slash path भी चलेगा, जैसे `DATA_DIR=C:/WavyData/private-data`।
4. Node.js 24 LTS install करें। `START-WEBSITE.bat` खोलें, या `npm ci --omit=dev` के बाद `npm start` चलाएँ।
5. v24 का data पहली बार SQLite में अपने-आप import होगा। Admin → Home settings → Database में folder और customer/order count जाँचें।

## याद रखें
- केवल HTML file खोलने या static hosting पर backend/database नहीं चलेगा।
- Hosting पर DATA_DIR को persistent disk/volume पर रखना जरूरी है। Host storage मिटा दे तो database भी मिट सकता है।
- SQLite database पहली बार start पर अपने-आप बनेगा; अलग database software install नहीं करना है।
- Admin से database backup download कर सकते हैं। यह private file है—इसे publicly share न करें।
- Migration के बाद पुराने JSON edit करने के बजाय admin panel इस्तेमाल करें।
- पुराना data पहले ही मिट गया हो तो उसे पुरानी backup से ही recover किया जा सकता है।

Detailed migration, backup और restore steps: **INSTALL-V26.md**।
