# Wavy Cloud v29 — panel lifecycle, separate service tasks, console commands

## Upgrade from v28 without resetting customer data

1. Stop the website process and make a private backup of the current application and persistent DATA_DIR. Do not upload that backup publicly.
2. Replace these application files from this archive:
   - server.js
   - pterodactyl.js
   - orders.html
   - script/orders.js
   - css/orders.css
   - package.json and package-lock.json (version metadata; dependencies are unchanged)
3. Keep your existing `.env`, DATA_DIR, SQLite database, panel settings, encryption keys and customer records. Do not replace the private data directory or point DATA_DIR to an empty folder. No database schema migration or data reset is required.
4. Use Node.js 24 LTS. If installing into a fresh application folder, run `npm ci`, then start with the SAME DATA_DIR and existing environment. Restart the website backend and hard-refresh the browser with Ctrl+Shift+R.

For a new installation, follow INSTALL-V27.md / INSTALL-V26.md. Start the Node server; do not open orders.html as a local file.

## Panel lifecycle is separate from order/payment history

- The backend reads each delivered server by its stored Pterodactyl Application API ID and verifies its owner, external ID and identifier.
- A valid server-specific 404 becomes **Deleted**. A suspended verified server becomes **Suspended**. The order, purchased plan snapshot, payment record and printable receipt remain intact.
- Deleted/suspended services have no Manage service action. Direct status, rename, power, credential and command requests are blocked too; hiding a button is not the security boundary.
- Only verified active servers can be selected in a partially revoked multi-server order. The rest remain in receipt history.
- API timeouts, permission errors and malformed responses become **Status unavailable**, not Deleted. Management fails closed until verification succeeds.
- Orders checks run when the page opens and approximately every 15 seconds while visible. Server reads may be cached for 10 seconds; **Refresh orders** bypasses that cache. A background observer runs every 30 seconds. This is polling, not a webhook: changes are not instantaneous and slow/unreachable panels can delay a refresh.
- Each management/command request performs fresh panel verification. Open console sessions also re-check remote service access every 10 seconds and close when revoked. Suspension already detected elsewhere closes the stream on its local access check.
- Unsuspending the same verified server in Pterodactyl restores management automatically when the paid, successful, unexpired website order is still eligible. Deleted servers are NOT recreated automatically.
- Read-only observation never suspends/unsuspends anything. The existing explicit admin order-status workflow is unchanged: saving Successful + Paid intentionally requests active panel access; saving Suspended requests suspension. Use the panel's unsuspend action for a panel-managed suspension you want to restore without changing the order.

## Cleaner customer service screens

- Cards and receipts display the actual purchased plan name and all stored specs, plus the customer server name.
- **Forgot password** opens only panel account/password tools and the panel's email-reset page. This does not reset the website login password.
- **Connect your server** shows Get your API key instructions and the customer's masked Client-key input FIRST. After connection, it reveals the server selector/name, live overview, power controls and console. The password form does not appear in this view.
- Both tasks start closed on the manage overview unless a task is explicitly selected in the URL. Print receipt stays available for suspended/deleted services.

## Sending console commands

- Connect your own non-admin Client API key (`ptlc_`) from the exact linked panel account. The administrator Application key is never used to send customer commands.
- Enter one command in **Server command**, then select **Send command**. The backend uses Pterodactyl's Client endpoint `POST /api/client/servers/{identifier}/command`.
- The key must have command/console access. The server must be online; the panel enforces its runtime and permissions. Suspended, installing, deleted, unverified, unpaid or expired services cannot use these controls.
- Inputs are limited to 1–1024 characters without line breaks/control characters. Commands are rate-limited to 60 requests per minute per client IP. Commands can modify your server; only send commands you intend to execute.
- The button confirms submission, NOT execution. Use live console output to confirm the effect. Commands are not stored in receipt history.
- Customer ownership, session authentication, CSRF, server identity and personal key ownership are verified on the backend. Arbitrary websocket command events are not forwarded; the form uses the guarded HTTP command endpoint.

## Validation

88 automated backend tests passed, including external suspension/deletion, unsuspend recovery, receipt retention, deletion across restarts, no automatic recreation, multi-server isolation, fail-closed permission/timeout/malformed responses, console revocation, command validation, CSRF and cross-customer denial. 16 browser UI checks passed. Desktop/mobile and dark/light sample screens were visually inspected.

These use a mock panel and safe sample data, not your live panel. Before customer rollout, test one disposable real server: suspend/unsuspend/delete in Pterodactyl, refresh Orders, verify receipt-only state, then verify a harmless command such as `list` on an active test server.

No real credentials or customer database are bundled.
