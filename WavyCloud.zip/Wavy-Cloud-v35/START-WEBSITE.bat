@echo off
setlocal
cd /d "%~dp0"
set "PATH=C:\Program Files\nodejs;%PATH%"
where node >nul 2>&1
if errorlevel 1 (
 echo Node.js is missing. Install it first, then reopen this file.
 pause
 exit /b 1
)
node -e "const [a,b]=process.versions.node.split('.').map(Number);if(a<22||(a===22&&b<13))process.exit(1);require('node:sqlite')"
if errorlevel 1 (
 echo Node.js 24 LTS is required/recommended. Install it, then reopen this file.
 pause
 exit /b 1
)
if not exist "node_modules\ws\package.json" goto install
if not exist "node_modules\nodemailer\package.json" goto install
goto run
:install
(
 echo Installing website dependencies (email and console support)...
 call npm install --omit=dev
 if errorlevel 1 (
  echo Package installation failed. Check your internet connection.
  pause
  exit /b 1
 )
)
:run
echo Keep this window open. Website: http://localhost:3000
echo Admin: http://localhost:3000/admin.html
start "" /b cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:3000"
call npm start
pause
