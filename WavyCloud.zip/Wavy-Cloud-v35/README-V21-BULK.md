# v21 admin patch — one setup for Intel Xeon Minecraft plans

This patch is for the working Wavy Cloud v20 website. It does not replace the server, credentials, catalog or private data.

## Install on Windows
1. Stop the website with Ctrl+C in its CMD window.
2. Back up your current website folder, including `private-data`.
3. Extract the patch ZIP. Copy `admin.html` to the folder containing `server.js`.
4. Merge the ZIP's `script` and `css` folders into your existing folders, replacing the corresponding files. Do NOT delete your existing folders.
5. Verify these FOUR files exist in the running website folder:
   - `admin.html`
   - `script/admin.js`
   - `script/panel-bulk.js` (new, required)
   - `css/admin.css`
6. Restart `START-WEBSITE.bat`. Open Admin and press Ctrl+F5.

Leave `private-data`, `server.js`, `pterodactyl.js`, API keys and other files unchanged. Nothing needs to be installed in the Pterodactyl panel or HuxRegister addon.

## Use
Admin → Panel API → Hosting plan: select the working Intel Minecraft plan (for example Drift). Ensure its delivery checkbox and existing mapping are complete.
- Preview Intel Minecraft setup.
- Review per-server RAM (MB), CPU (%), disk (MB), and which mappings will change. The mobile preview table can be swiped horizontally.
- By default already configured Intel mappings are kept. To update those too, tick “Update already configured Intel Minecraft plans too” and preview again.
- Apply preview to draft.
- Save panel settings above. Reload settings to confirm persistence.

The shared Egg ID, single Docker image, Startup, environment JSON, country Location IDs, swap, I/O and feature quotas come from the working source. RAM/CPU/disk are derived individually from each plan's catalog specs, not copied from the source. Missing/ambiguous specs stop the bulk action rather than inventing limits. Shared feature quotas do not create automatic backup schedules.

Scope is ONLY `minecraft-intel`: Intel Xeon Minecraft. AMD Minecraft and ALL VPS plans are untouched. This action configures mappings; it does NOT create servers, resize delivered servers, alter payments or edit existing receipts. Normal Successful + Paid provisioning still applies. Saved order specs remain authoritative, so older orders may require their original matching resource mapping.

For a newly added Intel Minecraft plan, publish its catalog first, reload Panel API, then preview/apply/save again using the same working source. You do not need to retype the Egg/image/JSON, but new plans are not silently auto-enabled in the background.

QA: 54 tests passed, including exact resources, preserving existing mappings, excluding VPS/AMD, malformed specs and new 5GB plans. Browser QA verified preview/draft do not save prematurely, stale preview protection, saved mappings after reload, and desktop/mobile rendering. Tests use a local mock panel; this patch does not access your live panel.
