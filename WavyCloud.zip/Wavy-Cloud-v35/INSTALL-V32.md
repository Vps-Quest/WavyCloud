# Wavy Cloud v32 — inactive-service removal and 30-minute Minecraft demos

This release adds only customer list removal and real timed demo provisioning. Payment methods, wallet details, coupons and payment approval rules for ordinary purchases are unchanged from v31.

## Upgrade

Back up your application and private DATA_DIR. Keep your existing `.env`, SQLite database, panel keys, catalog and payment settings. Do not reset private data.

Deploy the full code, or update these files together from v31:

- `server.js`, `pterodactyl.js`
- **NEW backend `demos.js`**
- **NEW frontend `script/demos.js`**
- `script/orders.js`, `script/commerce.js`, `script/account.js`, `script/admin.js`
- `css/index.css`, `css/orders.css`
- `admin.html`, `index.html`, `mincraft-hosting.html`, `vps-hosting.html`, `Intel-Xenon-plans.html`, `Amd-Epyc-plans.html`, `Amd-Ryzen-plans.html`
- `package.json` / `package-lock.json` for version metadata only (dependencies unchanged)

**Restart the Node backend**, then Ctrl+Shift+R. Keep using the same persistent DATA_DIR. Node.js 24 LTS recommended. New flags and demo records are automatically stored in the existing SQLite document store; no reset or manual schema migration is required.

## Remove inactive services from the customer list

My order requests now shows **Remove** for Pending requests, Suspended services and services verified as deleted/suspended in the panel. The button is also available on an eligible request's detail page.

Removal is authenticated, CSRF protected and restricted to the order owner. Before removing an order with linked servers, the backend checks their panel state again. Active, partially active or unverified servers cannot be hidden. A busy delivery/cleanup also blocks removal until it completes.

**Remove only hides the request from this customer's list.** It does not delete a Pterodactyl server, cancel/suspend an active server, refund a payment, erase payment evidence or delete the administrator's order record. Existing demo cleanup continues even if its card has been removed. If an administrator later restores a previously removed service to verified active access, it reappears automatically so the customer can manage it.

The previously deleted panel server cannot be recreated just by removing its card. Admin records remain available for auditing and support.

## Enable real demo servers once

1. Open **Admin → Panel API**.
2. Connect the correct panel with an **Application API key**, not a Client key. Users and Servers require Read & Write access; the read-only connection test alone does not prove create/suspend/delete permissions.
3. Configure your real Minecraft Egg, Docker image, startup/environment and positive panel location IDs under shared **Automatic Minecraft defaults**. They must work on your panel and have a suitable node/free allocation. The built-in default is Egg 1 / Java 25, but your panel may require different settings.
4. Select **Enable 30-minute Minecraft demos**, then **Save panel settings**. New demos are disabled on upgrade until the owner enables them.
5. Use a test customer to create one demo and confirm its panel assignment/access and cleanup in your environment before opening trials to visitors.

No new Payments & coupons controls were added. Demo settings live only in Panel API.

## Customer demo flow

- Click **Create demo server** on Minecraft hosting/plans. The old Discord-placeholder flow is replaced with real provisioning via the private backend.
- Sign in/register first. The form asks for a name, a configured location and explicit confirmation that demo data will be permanently deleted.
- Every demo uses fixed limits: **2 GB RAM, 100% CPU, 5 GB disk, one allocation, no databases or backups**. Shared Egg/image/startup/environment are reused. Client-submitted quotas, plan prices or durations cannot override these limits.
- A trial lasts **30 minutes from the initial creation request**, including provisioning, installation and account setup time. Retries never restart or extend that deadline.
- From v34 there is **one live demo per website account** and an **admin-configurable site-wide concurrent limit (default 10)**. Another demo can be created immediately after confirmed deletion; no daily cooldown applies. Removing a card cannot release an occupied slot. Parallel/double-click requests cannot allocate duplicate demos for the same account.
- A free demo is clearly marked **Demo / Not required** for payment, with a zero charge and expiry time. It is not falsely marked as a paid purchase.
- Open My order requests → Manage service. First-time customers complete the existing panel-login setup, then use Connect your server and their own verified Client key for live controls.
- Website/panel email and ownership protections remain in force. An existing unverified panel account, missing mapping or insufficient node resources produces an honest setup error, not a security bypass.
- VPS demos are not created; this feature is Minecraft only.

## Expiry and permanent deletion

The deadline is saved before the resource-creation request. The backend schedules expiry without requiring any customer page to remain open. At expiry it blocks website management, checks the demo's exact external ID, stored panel user and known server ID, suspends the demo, verifies suspension, then issues a normal Application API delete. Deletion is recorded only after absence is verified.

**The demo server and all its files are permanently deleted.** The panel customer account is retained because it may also own paid services. Paid servers are never cleanup targets. Trial records cannot be converted, extended or reapproved through the ordinary paid-order status form.

If suspension fails, deletion is not attempted. If deletion fails, the server remains suspended and cleanup retries approximately every 10 seconds. Ownership/identity changes block destructive actions and surface an admin-visible cleanup error. Disabling NEW demos or removing the website customer does not stop existing cleanup; the original private panel credentials/configuration are still needed.

**Operational requirement:** run one persistent Node backend instance, keep DATA_DIR and valid panel credentials, and keep the panel/node reachable. If the backend is stopped or the panel is unreachable, exact wall-clock suspension/deletion cannot be guaranteed. Expired trials are recovered from SQLite and cleanup resumes after backend restart/reconnection. A panel-side scheduler/watchdog would be needed for an independent hard cutoff during website outages; this release does not install one on your panel.

## Validation

- 119 backend tests passed, including all v31 payment/panel regressions plus removal ownership/CSRF/persistence, fixed trial quotas, timer persistence, suspend-before-delete ordering, failed cleanup retries, changed server identity/owner, ambiguous creation recovery, daily/global limits and paid-server isolation.
- Responsive browser checks cover light/dark desktop/mobile service lists, Remove, demo forms, unavailable/guest/cooldown states, creation navigation and the admin demo enable switch.
- Tests use a local mock panel; no real panel/customer resources were deleted during development.
