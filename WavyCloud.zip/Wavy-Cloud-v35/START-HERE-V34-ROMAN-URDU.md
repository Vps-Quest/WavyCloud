# Wavy Cloud v34 — update guide

## Is release mein
- Admin publish message: black background, white text.
- Minecraft/VPS hardware aur plan cards: light/dark theme mein readable headings, labels aur inputs.
- Home page ke final “Make something worth logging into” box ke andar top-right Join Discord button.
- Demo limit poori website ke liye shared hai: 10 ka matlab 10 accounts, har account ka sirf ek live demo.
- 30 minutes baad demo suspend, phir delete. Panel account aur doosre servers nahi delete hote.
- Confirmed deletion ke baad wahi account foran naya 30-minute demo le sakta hai. 24-hour cooldown nahi.
- Full hone par generic “No demo slots available”; slot khulne par availability automatically update. Doosre users ka expiry time/countdown nahi dikhaya jata. Koi reserved FIFO queue nahi hai.
- Creating, expired aur failed-cleanup demos bhi slot occupy karte hain jab tak remote deletion confirm na ho. Legacy duplicate records ko automatically delete nahi kiya jata; cleanup tak har un-deleted server capacity mein count hota hai, taake actual resource limit exceed na ho.

## Install / upgrade
1. Pehle private SQLite database ka backup lo.
2. Nayi application files replace karo. Apni existing .env aur persistent DATA_DIR ko preserve karo; inhein delete/overwrite mat karo.
3. `npm install` aur backend restart. Browser par Ctrl+Shift+R.
4. Admin → Panel API → Maximum concurrent demos mein desired shared limit save karo (1–100). Fixed 2 GB RAM, 100% CPU, 5 GB disk aur 30 minutes unchanged.
5. Valid Application API key, real location IDs, Egg/image/startup configured hon. Cleanup ke liye backend running rehna chahiye; panel outage mein retries hoti hain, deletion delay ho sakti hai.
6. Join Discord existing Admin → Payments & coupons → Discord invite URL use karta hai. Us screen ki functionality change nahi ki. Agar wahan link blank ho, `site-config.js` ka `discordInviteUrl` fallback hai. Dono blank hon to button honest unavailable message dikhata hai; koi fake invite nahi.

## Checks
Automated tests aur local real website/API integration checks. External Pterodactyl test fixture use hua; live production panel par destructive test nahi chalaya. Shared demo manager ek running backend process ki durable order reservations use karta hai; multiple independent backend processes ko ek deployment ki tarah run na karein.
