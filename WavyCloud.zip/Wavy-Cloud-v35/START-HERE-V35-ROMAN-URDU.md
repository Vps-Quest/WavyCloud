# Wavy Cloud v35 — Send Service + Account Info

Yeh **full merged website** hai. v34 ke demo slots, Discord, payment settings aur admin contrast fixes bhi is mein hain.

## Update kaise karein
1. Current website aur private DATA_DIR ka backup lein (Admin database backup bhi download karein).
2. Backend stop karein. v35 source files replace karein, **apni `.env`, DATA_DIR aur `wavy-cloud.sqlite` replace/delete na karein**. Agar DATA_DIR purane release folder ke andar tha to usay preserve/move karein aur `.env` mein uska sahi persistent absolute path rakhein.
3. Node 22.13+ (Node 24 recommended), `npm ci`, phir apne normal service/PM2 se backend restart karein.
4. Browser hard refresh karein. Sirf HTML upload karna kafi nahi: backend changes bhi zaroori hain.

## 📤 Send Service
- Your services page par summary ke neeche **Send Service** aur **Account Info** hain; zero orders wala customer bhi Account Info khol sakta hai.
- Sender apni verified active **paid** service select kare, recipient ka existing website email aur apna current website password de.
- Abhi server move nahi hota. Recipient ke Your services mein **Incoming services → Manage / receive service** aaye ga.
- Naya panel user isi website par username/password set kare. Existing panel account ho to apni **Client API key (ptlc_)** se same-email, non-admin account verify/link kare. Application API key customer form mein kabhi na dein.
- Recipient apna current website password de kar **Accept service & transfer ownership** kare. Is ke baad existing server ki Pterodactyl ownership recipient ko transfer hoti hai; sender se service aur ownership/access hat jati hai.
- **Server recreate nahi hota**; files, specs, IDs aur existing service expiry same rehti hain. Ek service/order mein multiple servers hon to sab transfer hote hain.
- Trial/demo, suspended, expired, unverified ya already-transfer-pending service send nahi hoti. Yeh billing/refund transaction nahi hai; monthly renewal/payment administrator manage karta rahega.
- Sender pending offer cancel aur recipient decline kar sakta hai, jab tak ownership update start na ho.

### Panel permissions aur safety
Application API ko Users + Servers Read/Write permissions chahiye. Panel ko Application server details mein `include=subusers` expose karna chahiye. **Transfer se pehle server ke saare subusers remove karein**, taake purana owner shared/subuser access se server na chala sake. API permission/identity verification fail ho to transfer block hota hai.

Agar remote update ke beech network fail ho, ownership journal database mein rehta hai aur controls lock hote hain. Recipient **Retry receiving service** kare; same server verify karke transfer resume hota hai. Partial/ambiguous transfer ko cancel kar ke ownership guess nahi ki jati. Running transfer ko finish kiye baghair dono involved accounts delete/profile-change nahi kar sakte. Real errors par panel permissions/connectivity fix karein; database journal manually clear na karein.

## 👤 Account Info
- Name, email, username aur optional **website password** edit kar sakte hain.
- Sensitive changes ke liye current website password required; duplicate website email/username reject hote hain.
- Website-managed panel account ka name/email/username bhi sync hota hai. **Website password aur panel password alag hain**; panel password existing panel-password page se change karein.
- Save ke baad doosre website sessions sign out hote hain aur current session refresh hota hai. Next login updated **email** se karein (username login add nahi hua).
- Existing externally linked panel account ka email yahan change nahi hota: panel mein update aur verified relink ke liye administrator ki help chahiye. Is tarah unrelated panel account overwrite nahi hota.
- Remote profile update ki confirmation fail ho to wohi submitted profile values retry karein. Pending values form mein dikhte hain.

## Account delete
**Delete website account** khol kar current password aur current email type karein. Apni remaining services pehle suspend hoti hain; suspension confirm na ho to account delete nahi hota. Website sessions revoke hote hain. **Panel account aur server files automatically delete nahi hotin**; admin order/receipt history aur billing records retain rehte hain. Billing/data removal ke liye support se baat karein. Yeh action irreversible website account deletion hai, is liye sirf apne account par karein.

## Tests
150 automated tests pass (existing regressions + new transfer/account tests). Local Chromium mein two-customer send/setup/accept/profile-sync flow test kiya; mobile/desktop, light/dark states inspect kiye. External Pterodactyl fixture use hua; aapke live production panel par server transfer execute nahi kiya gaya. Deploy ke baad pehle apne controlled test accounts/service se verify karein.

Purane release documents historical hain. v35 guide current behavior batati hai. Demos mein ab bhi one live demo/account, globally shared configured capacity aur confirmed cleanup ke baad immediate repeat hai; old daily cooldown ya per-account ten-demo quota nahi.
