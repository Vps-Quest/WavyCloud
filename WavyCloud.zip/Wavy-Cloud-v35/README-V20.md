# Wavy Cloud v20 — registration before Minecraft checkout

Stop the website first. Back up your current folder and especially `private-data`. Extract this release to a new folder; copy your existing `private-data` folder into it while the server is stopped. Do not replace your saved private data with empty test data. Run `START-WEBSITE.bat` (Node 20+) and hard-refresh the browser.

## What changed
- `panel-register.html`: first/last name, username, website email, chosen panel password, and website password confirmation. A real Pterodactyl account is created BEFORE a new Minecraft order can be accepted.
- Existing HuxRegister accounts: sign in to the panel, generate a personal non-admin Client API key, and verify/connect it on this page. Exact account ID + email is checked; matching an email alone never claims an existing account.
- Checkout redirects to registration if needed. The backend also enforces the gate against direct requests.
- Admin Successful AND Paid remains required for provisioning. Each saved plan's egg, location and exact RAM/CPU/disk limits are still required. Registration does not correct invalid server mappings.
- My products & orders: Start, Stop, Restart plus existing rename/status controls. Power requires an active paid delivered order and the owner's verified Client key; stop/restart asks for confirmation. A queued power command is not proof that the server is running.
- Customer password management: accounts created here use current website password re-authentication; accounts originally made in HuxRegister use their personal Client key + current panel password as well as website re-authentication.
- Includes the previous safe 422 diagnostic module (`panel-errors.js`). Old errors need an administrator retry to refresh.

## HuxRegister compatibility (not an addon replacement)
The uploaded HuxRegister 1.8 Blueprint shows registration as a modal on `/auth/login`, submitting POST `/extensions/huxregister/create-user` with `email`, `username`, `first_name`, `last_name`, `password`. Its controller delegates to Pterodactyl UserCreationService and converts exceptions to generic HTTP 500. This website deliberately uses Pterodactyl's authenticated official Application API for NEW account creation, not a cross-origin replica or modification of the addon's public web route. This preserves panel CSRF/verification policies on the original HuxRegister page. The addon package is NOT redistributed or modified.

## Setup
Admin → Panel API: root HTTPS panel URL, Application API key with Users and Servers Read & Write, enable and save. Never put this key in browser scripts. Configure every Minecraft plan using actual panel egg/image/startup/environment and location IDs. Application read test does not test write permissions, user registration or server capacity. Test with a disposable non-admin customer, then manually review the panel.

New account registration must succeed before placing a new Minecraft order. For an existing FAILED old order with no panel user, register/link from the website first, then retry that order's Successful + Paid → Save status. Do not create another paid order just to retry.

A separate website login and panel login still exist: this is NOT SSO and cannot read/clone website password hashes. Chosen panel passwords are sent only to the panel and not retained. Personal Client keys are encrypted in private backend storage. Credentials never belong in chat.

## Limitations
No embedded panel session/SSO, file manager, console, automatic key issuance, automatic expiry suspension or payment gateway. No automatic destructive migration of external accounts. Website actions verify saved ownership before accessing servers; installation, suspension, node capacity and API permission errors may still prevent delivery/control. Custom policies such as email verification and 2FA remain enforced by the panel. Test suite uses local mock panel APIs; successful LIVE creation on your panel has not been verified.
