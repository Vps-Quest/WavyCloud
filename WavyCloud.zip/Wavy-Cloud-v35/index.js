const root = document.documentElement;
const header = document.getElementById('site-header');
const nav = document.getElementById('main-nav');
const collapseBtn = document.getElementById('collapse-btn');
const modal = document.getElementById('video-container-bg');

function updateThemeIcon(){
  const icon = document.getElementById('toggle-mode-icon');
  if (!icon) return;
  const isLight = root.classList.contains('tw-light');
  icon.classList.toggle('bi-sun', !isLight);
  icon.classList.toggle('bi-moon', isLight);
  const favicon = document.getElementById('favicon');
  if (favicon) favicon.href = window.WavyCatalog?.home?.logo || './assets/logo/wavy-cloud-mark.png';
}
if (localStorage.getItem('wavy-theme') === 'light') root.classList.add('tw-light');
updateThemeIcon();
function toggleMode(){
  root.classList.toggle('tw-light');
  localStorage.setItem('wavy-theme', root.classList.contains('tw-light') ? 'light' : 'dark');
  updateThemeIcon();
}
window.toggleMode = toggleMode;

function toggleHeader(){
  const open = header.classList.toggle('nav-open');
  collapseBtn.setAttribute('aria-expanded', String(open));
  collapseBtn.innerHTML = `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="${open ? 'M6 6l12 12M18 6 6 18' : 'M4 6h16M4 12h16M4 18h16'}"/></svg>`;
  if (open) document.body.classList.add('modal-open'); else document.body.classList.remove('modal-open');
}
window.toggleHeader = toggleHeader;
nav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  if (header.classList.contains('nav-open')) toggleHeader();
}));

function openAccountModal(){
  const account = document.getElementById('account-modal');
  if (!account) return;
  window.dispatchEvent(new Event('wavy-account-open'));
  account.classList.add('open');
  account.setAttribute('aria-hidden','false');
  document.body.classList.add('modal-open');
}
function closeAccountModal(){
  const account = document.getElementById('account-modal');
  if (!account) return;
  account.classList.remove('open');
  account.setAttribute('aria-hidden','true');
  if (!document.getElementById('cart-drawer')?.classList.contains('open')) document.body.classList.remove('modal-open');
}
function setAuthMode(mode){
  const isRegister = mode === 'register';
  document.querySelector('.account-card h2').textContent = isRegister ? 'Create your account.' : 'Welcome back.';
  document.querySelector('.auth-intro').textContent = isRegister ? 'Create an account to submit hosting requests.' : 'Sign in to your account, or register to submit a hosting request.';
  document.getElementById('login-form')?.classList.toggle('is-hidden', isRegister);
  document.getElementById('register-form')?.classList.toggle('is-hidden', !isRegister);
  document.getElementById('login-tab')?.classList.toggle('active', !isRegister);
  document.getElementById('register-tab')?.classList.toggle('active', isRegister);
  document.getElementById('login-tab')?.setAttribute('aria-selected', String(!isRegister));
  document.getElementById('register-tab')?.setAttribute('aria-selected', String(isRegister));
}
function togglePassword(button){
  const input = button.parentElement.querySelector('input');
  if (!input) return;
  input.type = input.type === 'password' ? 'text' : 'password';
  button.textContent = input.type === 'password' ? 'Show' : 'Hide';
}
window.openAccountModal = openAccountModal; window.closeAccountModal = closeAccountModal;
window.setAuthMode = setAuthMode; window.togglePassword = togglePassword;

function openVideo(){ modal.classList.add('open'); modal.setAttribute('aria-hidden','false'); document.body.classList.add('modal-open'); }
function closeVideo(){ modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); document.body.classList.remove('modal-open'); }
window.openVideo = openVideo; window.closeVideo = closeVideo;
modal.addEventListener('click', (event) => { if (event.target === modal) closeVideo(); });
const accountModal = document.getElementById('account-modal');
const cartDrawer = document.getElementById('cart-drawer');
accountModal?.addEventListener('click', (event) => { if (event.target === accountModal) closeAccountModal(); });
document.addEventListener('keydown', (event) => { if (event.key === 'Escape') { closeVideo(); closeAccountModal(); closeCartDrawer(); if (header.classList.contains('nav-open')) toggleHeader(); } });

// Preserve the template's scroll-reveal motion, with a native fallback if the CDN is unavailable.
if (window.gsap && window.ScrollTrigger) {
  document.body.classList.add('motion-ready');
  gsap.registerPlugin(ScrollTrigger);
  gsap.utils.toArray('.reveal-up').forEach((element) => {
    gsap.fromTo(element, { opacity: 0, y: 35 }, { opacity: 1, y: 0, duration: .9, ease: 'power3.out', scrollTrigger: { trigger: element, start: 'top 88%', once: true } });
  });
  // Restore the original landing-page dashboard tilt: it straightens as the hero leaves the viewport.
  gsap.to('#dashboard', {
    scale: 1,
    y: 0,
    rotateX: '0deg',
    scrollTrigger: { trigger: '#hero-section', start: window.innerWidth > 1024 ? 'top 95%' : 'top 70%', end: 'bottom bottom', scrub: 1 }
  });
} else {
  document.body.classList.add('no-motion');
  document.querySelectorAll('.reveal-up').forEach((element) => {
    element.classList.add('is-visible');
    element.style.setProperty('opacity', '1', 'important');
    element.style.setProperty('transform', 'none', 'important');
  });
}

// FAQ accordion motion.
document.querySelectorAll('.faq-question').forEach((button) => {
  button.addEventListener('click', () => button.parentElement.classList.toggle('open'));
});

// Monthly/yearly plan toggle.
document.querySelectorAll('[data-billing]').forEach((button) => {
  button.addEventListener('click', () => {
    document.querySelectorAll('[data-billing]').forEach((item) => item.classList.toggle('active', item === button));
    const period = button.dataset.billing;
    document.querySelectorAll('.price strong[data-monthly]').forEach((price) => { price.textContent = `$${price.dataset[period]}`; });
  });
});

// Small header state change on scroll.
window.addEventListener('scroll', () => header.classList.toggle('scrolled', window.scrollY > 24), { passive: true });

// Accessible demo controls for the custom server panel.
const serverStatus = document.querySelector('.server-panel-status');
const serverDot = document.querySelector('.server-panel-dot');
const serverActionButtons = document.querySelectorAll('[data-server-action]');
const setServerState = (label, state) => {
  if (serverStatus) serverStatus.textContent = label;
  if (serverDot) serverDot.className = `server-panel-dot ${state || ''}`;
};
serverActionButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const action = button.dataset.serverAction;
    serverActionButtons.forEach((item) => item.setAttribute('aria-pressed', item === button ? 'true' : 'false'));
    if (action === 'start') setServerState('Get Server Now !', '');
    if (action === 'stop') setServerState('Server stopped', 'offline');
    if (action === 'restart') {
      setServerState('Restarting server…', 'restarting');
      window.setTimeout(() => setServerState('Get Server Now !', ''), 900);
    }
  });
});

// Keep the console at the newest log line and make the command field interactive.
const serverLog = document.getElementById('server-log');
if (serverLog) serverLog.scrollTop = serverLog.scrollHeight;
const commandForm = document.getElementById('server-command-form');
const commandInput = document.getElementById('server-command-input');
if (commandForm && commandInput && serverLog) {
  commandForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const command = commandInput.value.trim();
    if (!command) return;
    const line = document.createElement('div');
    line.textContent = `> ${command}`;
    line.style.color = '#8fe7ff';
    serverLog.appendChild(line);
    commandInput.value = '';
    serverLog.scrollTop = serverLog.scrollHeight;
  });
}

if (new URLSearchParams(location.search).get('account') === '1') {openAccountModal();if(new URLSearchParams(location.search).has('checkout'))setAuthMode('register');}

// Pause decorative motion off-screen, while hidden, or behind overlays.
(() => {
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const backgroundMotion=()=>{const paused=document.hidden||document.body.classList.contains('modal-open');root.classList.toggle('page-background-paused',paused);if(window.gsap)paused?gsap.globalTimeline.pause():gsap.globalTimeline.resume();};
 new MutationObserver(backgroundMotion).observe(document.body,{attributes:true,attributeFilter:['class']});
 document.addEventListener('visibilitychange',backgroundMotion);backgroundMotion();
 if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>entries.forEach(e=>e.target.classList.toggle('motion-offscreen',!e.isIntersecting)),{rootMargin:'80px'});document.querySelectorAll('.region-map,.server-panel,.hero-orb,.demo-orbit,.status-dot,.terminal-cursor').forEach(e=>observer.observe(e));}
 if(reduced.matches&&window.gsap){document.body.classList.add('no-motion');document.querySelectorAll('.reveal-up').forEach(e=>{e.style.opacity='1';e.style.transform='none';});gsap.globalTimeline.clear();}
})();
