# v35 installation and operational notes

Read START-HERE-V35-ROMAN-URDU.md first. This is a full source release, not an HTML-only patch.

- Preserve `.env` and the persistent private DATA_DIR, including SQLite data and encryption key; back up before replacing source. Stop the old process before moving the private directory. Do not start two writers against one DATA_DIR.
- Run Node 22.13+ (24 recommended), `npm ci`, `npm start` or restart the existing process manager. Serve HTTPS through the existing reverse proxy. Keep Pterodactyl and SQLite private credentials out of the public web root.
- No manual schema migration is needed: new optional user/order fields use the existing durable document storage. Existing customers/orders/settings remain intact.
- New root `customer-features.js` is backend-only; public client is `script/customer-features.js` plus `css/customer-features.css`. Deploy all changed files and restart.
- The Application API key needs Users and Servers read/write permissions. Safe ownership transfer requires reading server subusers; remove subusers before moving ownership. No server data is copied/deleted by transfer.
- Transfers are explicit recipient acceptance, not immediate sender-side moves. Pending and partial transfer state is durable. On remote failure the recipient retries; a partially moved multi-server order stays locked rather than exposing mixed ownership controls. Resolve panel errors before retrying. Do not erase its journal.
- Profile email/username changes for managed panel accounts synchronize remotely before website identity commits. Pending remote confirmations reserve the new email/username and must be retried with the same values. Existing external panel account email changes require administrator relinking.
- Self deletion suspends owned services and revokes website sessions. It does not delete panel accounts/server files or erase administrator financial/order history. Existing independent paid billing arrangements must be handled separately.
- Website password changes do not change panel passwords. Login remains email/password. Existing live Client connections are revoked on identity changes and the customer can reconnect with their own Client key.

Verification: `npm test` (150 tests). Local browser QA covers two distinct customers and real website APIs with an external panel fixture; no production deployment or live customer server mutation is included.
