# Wavy Cloud v27 — कैसे चलाना और auto setup करना है

1. पुराना server बंद करें। Data folder का backup लें; उसे delete/replace न करें।
2. नई ZIP अलग folder में extract करें। Node.js 24 LTS इस्तेमाल करें।
3. `.env` में DATA_DIR को अपनी पुरानी persistent data folder पर रखें। v26 SQLite data वहीं से इस्तेमाल होगा।
4. `START-WEBSITE.bat` चलाएँ। Website: http://localhost:3000 — Admin: http://localhost:3000/admin.html
5. Admin → Panel API खोलें। अपना URL और API key खुद भरें।
6. Automatic Minecraft defaults में Egg 1, Java 25 image, startup, 5 backups और 1 allocation पहले से भरे हैं। बस असल location IDs **एक बार** भरकर Save panel settings करें।
7. अब Minecraft plan बनाएँ और उसके specs में जैसे `5 GB RAM`, `100% CPU`, `40 GB NVMe storage` लिखें। Publish पर mapping अपने-आप बनेगी। हर plan पर Egg/image/startup दोबारा भरने की जरूरत नहीं है।

पुराने manual mappings नहीं बदलेंगे, जब तक आप Apply defaults to all existing Minecraft mappings विकल्प चुनकर save न करें। Running servers resize नहीं होंगे। नया server केवल Successful + Paid order पर बनेगा।

अगर आपके असल panel में Egg 1 या Java 25 अलग है, तो shared default एक बार सही करें। Location ID guess नहीं की गई है। Setup और safety details: **INSTALL-V27.md**। पुराने data की migration/backup/restore: **INSTALL-V26.md**।
