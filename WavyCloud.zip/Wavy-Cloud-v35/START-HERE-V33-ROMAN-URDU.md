# v33 — Demo slots aur same-site panel registration

## Admin mein limit kaise lagani hai
Admin → Panel API → Maximum concurrent demos mein number likho, misal ke taur par 10, phir Save panel settings karo. Range 1–100 hai; agar pehle koi saved value nahi hai to default 10 hai. 30-minute demo checkbox bhi enabled hona chahiye. Duration badalne ka option nahi diya gaya: demo ab bhi 30 minutes ka hai.

10 ki limit par ek waqt mein 10 customers ke demos ho sakte hain. 11wein customer ko No demo slots available aur next scheduled expiry ka estimated countdown nazar aata hai. Page har 10 seconds mein availability dobara check karta hai; Check slots again bhi hai. Slot milne par customer khud Create button dabata hai. Reserved queue ya automatic order creation nahi hai.

Slot tab free hota hai jab purana demo panel se delete hona confirm ho. Sirf timer khatam hone, user entry hide karne, setup fail hone, backend restart ya suspension se slot jaldi free nahi hota. Cleanup fail ho to occupied rahta hai aur cleanup retry hota hai. Limit kam karne se pehle se chalne wale demos band/delete nahi hote; naye demos tab tak rukte hain jab tak count nayi limit se neeche na aa jaye.

## Customer ka flow
1. Website account se sign in/register.
2. Create demo server: naam aur configured France location select kare, deletion warning accept kare.
3. Create 30-minute demo par backend Pterodactyl mein us customer ka verified account create/reuse karta hai aur 2 GB RAM / 100% CPU / 5 GB disk ka server assign karta hai.
4. Naye panel account ka username aur password set karne ka form isi website ke dialog mein aa jata hai. Customer current website password se identity confirm kare, apna panel username aur naya panel password do martaba likhe, phir Register panel login & continue kare. Koi doosra duplicate Pterodactyl account register nahi karna.
5. Success par remaining time aur service/panel links milte hain. Agar panel login pehle se ready hai to dobara registration nahi maangi jati. Dialog band kar de to My order requests → demo service se registration resume ho sakti hai.
6. 30 minutes par sirf demo Minecraft server pehle suspend phir permanently delete hota hai. Customer ka website account, panel account aur chosen panel login rehta hai. Trial files wapas nahi aati.

Timer initial creation request se shuru hota hai. Installation aur panel registration ka waqt isi 30 minutes mein count hota hai; registration timer reset/extend nahi karti. v34 update: 24-hour cooldown hata diya gaya hai. Ek account ka sirf ek live demo; confirmed deletion ke baad foran dobara create kar sakta hai.

## Update/install
- Pehle existing database/DATA_DIR aur .env ka backup lo.
- Full merged code deploy karo. .env, private data aur database overwrite/delete mat karna.
- Dependencies ke liye npm ci, phir apne process manager se Node backend restart karo.
- Browser Ctrl+Shift+R. Admin → Panel API → demo limit 10 → Save panel settings.
- Shared Minecraft Egg/image/startup/environment, real location IDs aur Application API Users/Servers Read & Write sahi hon. Location ID guess nahi ki gayi.
- Backend aur panel ko running rakho. Outage mein exact expiry-second par suspend/delete mumkin nahi; available hone par cleanup retry hota hai. Countdown estimated hai, confirmed reserved slot nahi.

Payments/coupons aur paid hosting resources is update mein nahi badle. Number of demos node capacity ki guarantee nahi hai: 10 demos ke liye kam az kam unke total resources aur allocations panel par available hone chahiye.

## Checks
133 automated tests pass. Real local browser + website backend ke saath cap save/reload, full slots/wait state, availability refresh, France selection, first panel user creation, same-site panel password setup aur success flow verify hue. Panel side par test double use hua; tumhare live panel par test nahi hua. Ek API test expiry ke baad user account/login retained rehna aur slot free hona bhi verify karta hai.
