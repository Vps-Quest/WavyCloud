'use strict';
// Never display remote detail strings, response bodies, request values or secrets.
function fieldName(raw){
 if(typeof raw!=='string'||raw.length>160)return null;
 let name=raw.replace(/^\/data\/attributes\//,'').replace(/^\/?(?:data\.)?attributes\./,'').replace(/\//g,'.');
 if(/^(?:email|username|first_name|last_name|password|external_id|language|root_admin|name|user|egg|docker_image|startup|description|skip_scripts|start_on_completion|oom_disabled)$/.test(name))return name;
 if(/^limits\.(?:memory|swap|disk|io|cpu|threads|oom_disabled)$/.test(name))return name;
 if(/^feature_limits\.(?:databases|allocations|backups)$/.test(name))return name;
 if(/^deploy\.(?:locations(?:\.\d+)?|dedicated_ip|port_range(?:\.\d+)?)$/.test(name))return name;
 if(/^allocation\.(?:default|additional(?:\.\d+)?)$/.test(name))return name;
 if(/^environment(?:\.[A-Z][A-Z0-9_]{0,63})?$/.test(name))return name;
 if(['limits','feature_limits','deploy','allocation'].includes(name))return name;
 return null;
}
function reason(detail){
 if(typeof detail!=='string')return 'invalid or rejected value';
 if(/already (?:been )?taken|already exists|must be unique|duplicate/i.test(detail))return 'already in use';
 if(/required|must be present/i.test(detail))return 'required / missing';
 if(/email/i.test(detail)&&/valid|format/i.test(detail))return 'invalid email format';
 if(/regex|format|alpha/i.test(detail))return 'invalid format';
 if(/at least|at most|between|minimum|maximum|greater than|less than|too long|too short/i.test(detail))return 'invalid length or range';
 if(/integer|numeric|number/i.test(detail))return 'must be a valid number';
 if(/selected .*invalid|does not exist|not found/i.test(detail))return 'invalid selection / ID';
 return 'invalid or rejected value';
}
function stage(route,method,scope){
 const path=String(route).split('?')[0];
 if(scope==='client')return 'personal Client API request';
 if(path==='/users'&&method==='POST')return 'panel user creation';
 if(path.startsWith('/users')&&method==='PATCH')return 'panel account update';
 if(path.startsWith('/users'))return 'panel user lookup';
 if(path==='/servers'&&method==='POST')return 'server creation';
 if(path.startsWith('/servers')&&method==='PATCH')return 'server update';
 if(path.startsWith('/servers'))return 'server lookup';
 return 'panel request';
}
function formatPanelError(status,payload,{route='',method='GET',scope='application'}={}){
 const prefix='Panel API returned HTTP '+status+' during '+stage(route,method,scope)+'.';
 if(status===401)return prefix+' Key was rejected. Check the saved key and panel URL; replace a revoked key.';
 if(status===403)return prefix+(scope==='client'?' Access denied. Check your personal Client key, account permissions and allowed-IP restriction.':' Access denied. The Application key needs Users and Servers Read & Write; check its allowed-IP restriction.');
 const messages=[];const errors=payload?.errors;
 if(Array.isArray(errors))for(const e of errors.slice(0,12)){
  const field=fieldName(e?.source?.field)||fieldName(e?.source?.pointer)||fieldName(e?.field);
  if(field)messages.push(field+': '+reason(e.detail||e.message));
  else if(e?.code==='NoViableNodeException')messages.push('No eligible node: check location, node availability and resource capacity');
  else if(e?.code==='NoAvailableAllocationException')messages.push('No free allocation: check node ports/allocations');
 }
 else if(errors&&typeof errors==='object')for(const [raw,values]of Object.entries(errors).slice(0,12)){const field=fieldName(raw);if(field)messages.push(field+': '+reason(Array.isArray(values)?values[0]:values));}
 if(messages.length)return prefix+' '+[...new Set(messages)].join('; ')+'.';
 if(status===422)return prefix+' Request data was rejected. The panel did not supply a supported field name; check its application log for validation details. No raw response or secret is displayed.';
 return prefix+' Check panel availability and request settings. No raw response or secret is displayed.';
}
module.exports={formatPanelError};
