# v31 اپڈیٹ

1. پہلے website اور private DATA_DIR / database کا backup لیں۔
2. نئی application files لگائیں لیکن **اپنی `.env`، SQLite database، DATA_DIR اور panel settings نہ بدلیں**۔ `INSTALL-V31.md` میں changed files کی مکمل فہرست ہے۔ نئی `payments.js` اور `script/theme-icon.js` بھی لازمی لگائیں۔
3. **Backend restart** کریں، پھر **Ctrl+Shift+R** کریں۔
4. Admin → **Payments & coupons** میں ہر method کو Available / Coming soon کریں، wallet receiving details چیک کریں اور UPI کے لیے **اپنا اصلی Discord invite** ڈالیں۔ Coupon code، discount percentage اور Enabled منتخب کرکے **Save payments & coupons** دبائیں۔
5. Screenshots والی bank/name/number details آپ کی تصدیق کے مطابق ابتدائی طور پر رکھی گئی ہیں؛ admin سے کسی بھی وقت بدل سکتے ہیں۔
6. Wallet checkout میں sender name، transaction ID اور screenshot تینوں لازمی ہیں۔ PNG/JPG/WebP، زیادہ سے زیادہ 2 MB۔ Admin → Orders میں proof دیکھ کر transfer خود verify کریں؛ صرف screenshot سے Paid یا delivery نہیں ہوگی، **Successful + Paid** approval ضروری ہے۔
7. Prices USD ہیں؛ PKR/INR conversion خودکار نہیں۔ صحیح payable amount اور currency پہلے support سے confirm کروائیں۔ Card کا Available switch اصل card gateway نہیں بناتا، صرف manual instructions دیتا ہے۔
8. نئے Minecraft plan میں `8 GB RAM`، `400% CPU`، `50 GB NVMe storage` جیسی واضح specs دیں۔ Shared automatic defaults میں حقیقی panel location IDs ایک بار سیٹ کریں۔ Egg، image اور startup ہر نئے plan کے لیے دوبارہ ڈالنے کی ضرورت نہیں۔ Existing manual overrides محفوظ رہتے ہیں۔

Delivery notification بیس سیکنڈ بعد ہٹ جائے گا۔ Guest کو checkout سے پہلے registration/sign-in دکھے گی اور cart محفوظ رہے گا۔ Checkout/admin کے sun/moon icons اور wallet popups دونوں themes میں اپڈیٹ ہیں۔

تفصیلی upgrade کے لیے **INSTALL-V31.md** پڑھیں۔
